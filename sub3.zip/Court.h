#ifndef COURT_H
#define COURT_H

#include "EventGroup.h"
#include "NetballMatch.h"
/**
 * @brief Groups matches on a particular court
 * @role Composite Pattern - Composite
 * @role Observer Pattern - Concrete Subject and Observer
 */
class Court : public EventGroup {
private:
    std::string courtType; // "Indoor" or "Outdoor"
    std::string surface;   // "Hard", "Clay", "Grass"
    int matchCapacity;
    
public:
    Court(const std::string& name, const std::string& type, 
          const std::string& surface, int capacity = 3);
    virtual ~Court();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    
    // Court operations
    void addMatch(NetballMatch* match);
    void removeMatch(NetballMatch* match);
    bool hasMatch(const std::string& matchName) const;
};

#endif
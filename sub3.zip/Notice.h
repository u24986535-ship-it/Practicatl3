#ifndef NOTICE_H
#define NOTICE_H

#include <string>
#include <ctime>

/**
 * @brief Enumeration of notice types
 */
enum NoticeType {
    OPEN,
    CLOSE,
    SCHEDULE_CHANGE,
    CAPACITY_ALERT,
    WEATHER_ALERT,
    PAUSE,
    RESUME,
    EVACUATE,
    SCORE_UPDATE,
    MATCH_START,
    MATCH_END,
    WARMUP_START,
    WARMUP_END,
    CUSTOM
};

/**
 * @brief Represents a notification message
 */
class Notice {
private:
    NoticeType type;
    std::string message;
    time_t timestamp;
    std::string source;
    
public:
    Notice(NoticeType type, const std::string& message, const std::string& source = "")
        : type(type), message(message), source(source) {
        timestamp = time(nullptr);
    }
    
    ~Notice() {}
    
    NoticeType getType() const { return type; }
    std::string getMessage() const { return message; }
    time_t getTimestamp() const { return timestamp; }
    std::string getSource() const { return source; }
    
    std::string getTypeString() const {
        switch(type) {
            case OPEN: return "OPEN";
            case CLOSE: return "CLOSE";
            case SCHEDULE_CHANGE: return "SCHEDULE_CHANGE";
            case CAPACITY_ALERT: return "CAPACITY_ALERT";
            case WEATHER_ALERT: return "WEATHER_ALERT";
            case PAUSE: return "PAUSE";
            case RESUME: return "RESUME";
            case EVACUATE: return "EVACUATE";
            case SCORE_UPDATE: return "SCORE_UPDATE";
            case MATCH_START: return "MATCH_START";
            case MATCH_END: return "MATCH_END";
            case WARMUP_START: return "WARMUP_START";
            case WARMUP_END: return "WARMUP_END";
            default: return "CUSTOM";
        }
    }
};

#endif
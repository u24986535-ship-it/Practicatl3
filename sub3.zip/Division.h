#ifndef DIVISION_H
#define DIVISION_H

#include "EventGroup.h"

/**
 * @brief Groups matches by age division
 * @role Composite Pattern - Composite
 * @role Observer Pattern - Concrete Subject and Observer
 */
class Division : public EventGroup {
private:
    std::string ageGroup;
    int maxTeams;
    std::vector<std::string> teams;
    
public:
    Division(const std::string& name, const std::string& ageGroup, int maxTeams);
    virtual ~Division();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    
    // Division operations
    void addTeam(const std::string& team);
    // Fix: cast maxTeams to size_t for comparison
    bool isFull() const { return teams.size() >= static_cast<size_t>(maxTeams); }
};

#endif
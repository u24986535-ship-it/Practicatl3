#ifndef UMPIREBRIEFING_H
#define UMPIREBRIEFING_H

#include "EventUnit.h"
#include "Observer.h"
#include <vector>
#include <string>

/**
 * @brief Represents an umpire briefing session
 * @role Composite Pattern - Leaf
 * @role Observer Pattern - Concrete Subject and Observer
 */
class UmpireBriefing : public EventUnit, public Observer {
private:
    int matchID;
    std::string briefingTime;
    bool isConducted;
    std::vector<std::string> umpires;
    
public:
    UmpireBriefing(const std::string& name, int matchId, const std::string& time);
    virtual ~UmpireBriefing();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    virtual std::string getName() const { return name; }
    
    // Observer interface
    virtual void update(Notice* notice);
    
    // Briefing operations
    void conductBriefing();
    void addUmpire(const std::string& umpire);
    bool getIsConducted() const { return isConducted; }
};

#endif
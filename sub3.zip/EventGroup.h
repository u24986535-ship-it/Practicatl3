#ifndef EVENTGROUP_H
#define EVENTGROUP_H

#include "EventComponent.h"
#include "Subject.h"
#include "Observer.h"
#include <vector>
#include <algorithm>

/**
 * @brief Abstract composite class for event groups
 * @role Composite Pattern - Composite
 * @role Observer Pattern - Concrete Subject and Observer
 */
class EventGroup : public EventComponent, public Subject, public Observer {
protected:
    std::string name;
    std::vector<EventComponent*> children;
    bool isOpen;
    
public:
    EventGroup(const std::string& name);
    virtual ~EventGroup();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    virtual std::string getName() const { return name; }
    
    // Composite operations
    virtual void add(EventComponent* component);
    virtual void remove(EventComponent* component);
    virtual EventComponent* findChild(const std::string& name);
    virtual int getChildCount() const { return children.size(); }
    
    // Subject interface (inherited)
    virtual void attach(Observer* observer);
    virtual void detach(Observer* observer);
    virtual void notify();
    
    // Observer interface
    virtual void update(Notice* notice);
    
    // Helper methods
    virtual void propagateNotification(Notice* notice);
    std::vector<EventComponent*> getChildren() const { return children; }
};

#endif
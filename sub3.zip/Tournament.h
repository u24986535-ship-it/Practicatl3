#ifndef TOURNAMENT_H
#define TOURNAMENT_H

#include "EventGroup.h"

// Forward declaration to avoid circular dependency
class TournamentDay;

/**
 * @brief Root composite representing the entire tournament
 * @role Composite Pattern - Composite
 * @role Observer Pattern - Concrete Subject and Observer
 */
class Tournament : public EventGroup {
private:
    int year;
    std::string venue;
    
public:
    Tournament(const std::string& name, int year, const std::string& venue);
    virtual ~Tournament();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    
    // Tournament-specific operations
    void addDay(TournamentDay* day);
    TournamentDay* findDay(const std::string& dayName);
};

#endif
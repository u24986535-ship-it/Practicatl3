#ifndef OBSERVER_H
#define OBSERVER_H

#include "Notice.h"

/**
 * @brief Abstract base class for observers
 * @role Observer Pattern - Observer
 */
class Observer {
public:
    virtual ~Observer() {}
    virtual void update(Notice* notice) = 0;
};

#endif
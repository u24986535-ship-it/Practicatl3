#ifndef SCOREBOARD_H
#define SCOREBOARD_H

#include "EventUnit.h"
#include "Observer.h"

// Forward declaration to avoid circular dependency
class NetballMatch;

/**
 * @brief Represents a scoreboard display
 * @role Composite Pattern - Leaf
 * @role Observer Pattern - Concrete Observer
 */
class ScoreBoard : public EventUnit, public Observer {
private:
    std::string boardID;
    int matchID;
    int homeScore;
    int awayScore;
    bool isActive;
    std::string currentMatchName;
    NetballMatch* observedMatch;  // Forward declared
    
public:
    ScoreBoard(const std::string& name, const std::string& id);
    virtual ~ScoreBoard();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    virtual std::string getName() const { return name; }
    
    // Observer interface
    virtual void update(Notice* notice);
    
    // ScoreBoard operations
    void displayScore();
    void updateMatch(int home, int away);
    void setMatch(NetballMatch* match);  // Forward declared
    
    std::string getBoardID() const { return boardID; }
};

#endif
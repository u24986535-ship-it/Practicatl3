#ifndef SPECTATORGATE_H
#define SPECTATORGATE_H

#include "EventUnit.h"
#include "Observer.h"

/**
 * @brief Represents a spectator entry gate
 * @role Composite Pattern - Leaf
 * @role Observer Pattern - Concrete Observer
 */
class SpectatorGate : public EventUnit, public Observer {
private:
    int gateNumber;
    int maxCapacity;
    int currentOccupancy;
    double entryRate; // Spectators per minute
    
    // Helper method for capacity alerts
    void handleCapacityAlert(Notice* notice);
    
public:
    SpectatorGate(const std::string& name, int gateNum, int capacity = 1000);
    virtual ~SpectatorGate();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    virtual std::string getName() const { return name; }
    
    // Observer interface
    virtual void update(Notice* notice);
    
    // Gate operations
    bool admitSpectator();
    int getRemainingCapacity() const;
    void setEntryRate(double rate);
    double getOccupancyRate() const;
};

#endif
#ifndef TOURNAMENTDAY_H
#define TOURNAMENTDAY_H

#include "EventGroup.h"

/**
 * @brief Groups activities occurring on a particular day
 * @role Composite Pattern - Composite
 * @role Observer Pattern - Concrete Subject and Observer
 */
class TournamentDay : public EventGroup {
private:
    std::string date;
    int dayNumber;
    bool isComplete;
    
public:
    TournamentDay(const std::string& name, const std::string& date, int dayNum);
    virtual ~TournamentDay();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    
    // Day operations
    void markComplete();
    bool getIsComplete() const { return isComplete; }
    std::string getDate() const { return date; }
};

#endif
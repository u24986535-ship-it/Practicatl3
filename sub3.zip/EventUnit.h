#ifndef EVENTUNIT_H
#define EVENTUNIT_H

#include "EventComponent.h"
#include "Observer.h"
#include "Subject.h"
#include "Notice.h"

/**
 * @brief Abstract base class for leaf components
 * @role Composite Pattern - Leaf
 */
class EventUnit : public EventComponent, public Subject {
protected:
    std::string name;
    bool isOpen;
    
public:
    EventUnit(const std::string& name) : name(name), isOpen(false) {}
    virtual ~EventUnit() {}
    
    virtual std::string getName() const { return name; }
    void setIsOpen(bool open) { isOpen = open; }
};

#endif
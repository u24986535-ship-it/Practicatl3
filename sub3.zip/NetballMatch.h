#ifndef NETBALLMATCH_H
#define NETBALLMATCH_H

#include "EventUnit.h"
#include "Notice.h"

/**
 * @brief Represents an individual netball match
 * @role Composite Pattern - Leaf
 * @role Observer Pattern - Concrete Subject
 */
class NetballMatch : public EventUnit {
public:
    enum MatchStatus { SCHEDULED, IN_PROGRESS, PAUSED, COMPLETED, CANCELLED };
    
private:
    int score;              // Initialize first
    int opponentScore;      // Initialize second
    MatchStatus status;     // Initialize third
    std::string courtName;  // Initialize fourth
    std::string homeTeam;   // Initialize fifth
    std::string awayTeam;   // Initialize sixth
    bool isOutdoor;         // Initialize last
    
public:
    NetballMatch(const std::string& name, const std::string& home, 
                 const std::string& away, bool outdoor = false);
    virtual ~NetballMatch();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    virtual std::string getName() const { return name; }
    
    // Match operations
    void startMatch();
    void updateScore(int newScore, int newOpponentScore);
    void setStatus(MatchStatus newStatus);
    void pauseMatch();
    void resumeMatch();
    void endMatch();
    
    // Getters
    int getScore() const { return score; }
    int getOpponentScore() const { return opponentScore; }
    MatchStatus getStatus() const { return status; }
    std::string getCourtName() const { return courtName; }
    bool getIsOutdoor() const { return isOutdoor; }
    
    std::string statusToString(MatchStatus s) const;
};

#endif
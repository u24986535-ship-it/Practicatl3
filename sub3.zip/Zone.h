#ifndef ZONE_H
#define ZONE_H

#include "EventGroup.h"
#include "Court.h"
/**
 * @brief Groups courts within an area
 * @role Composite Pattern - Composite
 * @role Observer Pattern - Concrete Subject and Observer
 */
class Zone : public EventGroup {
private:
    std::string area;
    bool isOutdoor;
    int courtCount;
    
public:
    Zone(const std::string& name, const std::string& area, bool outdoor = false);
    virtual ~Zone();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    
    // Zone operations
    void addCourt(Court* court);
    int getCourtCount() const;  // Just declaration, not inline definition
    
    bool getIsOutdoor() const { return isOutdoor; }
};

#endif
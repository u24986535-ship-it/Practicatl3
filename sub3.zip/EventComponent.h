#ifndef EVENTCOMPONENT_H
#define EVENTCOMPONENT_H

#include <string>
#include <iostream>

/**
 * @brief Abstract base class for all event components
 * @role Composite Pattern - Component
 */
class EventComponent {
public:
    virtual ~EventComponent() {}
    
    virtual void open() = 0;
    virtual void close() = 0;
    virtual void reportStatus() const = 0;
    virtual int getCapacity() const = 0;
    virtual std::string getName() const = 0;
};

#endif
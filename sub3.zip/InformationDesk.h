#ifndef INFORMATIONDESK_H
#define INFORMATIONDESK_H

#include "EventUnit.h"
#include "Observer.h"
#include <vector>

/**
 * @brief Represents an information desk
 * @role Composite Pattern - Leaf
 * @role Observer Pattern - Concrete Observer
 */
class InformationDesk : public EventUnit, public Observer {
private:
    std::string deskID;
    std::string location;
    std::vector<std::string> services;
    std::string currentAnnouncement;
    bool isActive;
    
public:
    InformationDesk(const std::string& name, const std::string& id, 
                    const std::string& loc);
    virtual ~InformationDesk();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    virtual std::string getName() const { return name; }
    
    // Observer interface
    virtual void update(Notice* notice);
    
    // Desk operations
    void provideInfo(const std::string& info);
    void addService(const std::string& service);
    void broadcastAnnouncement(const std::string& announcement);
};

#endif
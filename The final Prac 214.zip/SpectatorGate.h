#ifndef SPECTATORGATE_H
#define SPECTATORGATE_H

#include "EventUnit.h"
#include "Observer.h"

/**
 * @brief Represents a spectator entry gate for the tournament venue.
 * 
 * This class manages spectator admission through a gate, tracking capacity
 * and entry rates. It responds to various notices such as capacity alerts
 * and weather alerts to adjust operations.
 * 
 * @role Composite Pattern - Leaf
 * @role Observer Pattern - Concrete Observer
 */
class SpectatorGate : public EventUnit, public Observer {
private:
    int gateNumber;          ///< Unique number identifying the gate
    int maxCapacity;         ///< Maximum number of spectators this gate can handle
    int currentOccupancy;    ///< Current number of spectators admitted
    double entryRate;        ///< Spectators per minute entry rate
    
    /**
     * @brief Handles capacity alert notices.
     * 
     * When capacity reaches 80%, the entry rate is reduced. When it reaches
     * 95%, the gate is closed to prevent overcrowding.
     * 
     * @param notice The capacity alert notice
     */
    void handleCapacityAlert(Notice* notice);
    
public:
    /**
     * @brief Constructs a SpectatorGate.
     * 
     * @param name The gate name
     * @param gateNum The gate number
     * @param capacity The maximum capacity (defaults to 1000)
     */
    SpectatorGate(const std::string& name, int gateNum, int capacity = 1000);
    
    /**
     * @brief Destroys the SpectatorGate.
     */
    virtual ~SpectatorGate();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    virtual std::string getName() const { return name; }
    
    // Observer interface
    virtual void update(Notice* notice);
    
    /**
     * @brief Admits a spectator through the gate.
     * 
     * @return bool true if admitted successfully, false if gate is closed or at capacity
     */
    bool admitSpectator();
    
    /**
     * @brief Gets the remaining capacity of the gate.
     * 
     * @return int Number of additional spectators that can be admitted
     */
    int getRemainingCapacity() const;
    
    /**
     * @brief Sets the entry rate for the gate.
     * 
     * @param rate The new entry rate in spectators per minute
     */
    void setEntryRate(double rate);
    
    /**
     * @brief Gets the current occupancy rate as a fraction.
     * 
     * @return double Occupancy rate between 0.0 and 1.0
     */
    double getOccupancyRate() const;
};

#endif
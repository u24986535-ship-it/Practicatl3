#include "InformationDesk.h"
#include <iostream>
#include <algorithm>

InformationDesk::InformationDesk(const std::string& name, const std::string& id, 
                                 const std::string& loc)
    : EventUnit(name), deskID(id), location(loc), isActive(false) {
    // Add default services
    services.push_back("General Information");
    services.push_back("Schedule Lookup");
    services.push_back("Lost and Found");
    std::cout << "Information Desk " << deskID << " created at " << location << std::endl;
}

InformationDesk::~InformationDesk() {
    std::cout << "Information Desk " << deskID << " destroyed." << std::endl;
}

void InformationDesk::open() {
    setIsOpen(true);
    isActive = true;
    std::cout << "Information Desk " << deskID << " opened." << std::endl;
}

void InformationDesk::close() {
    setIsOpen(false);
    isActive = false;
    std::cout << "Information Desk " << deskID << " closed." << std::endl;
}

void InformationDesk::reportStatus() const {
    std::cout << "=== Information Desk: " << name << " ===" << std::endl;
    std::cout << "ID: " << deskID << std::endl;
    std::cout << "Location: " << location << std::endl;
    std::cout << "Status: " << (isActive ? "Active" : "Inactive") << std::endl;
    std::cout << "Services offered:" << std::endl;
    for (const auto& service : services) {
        std::cout << "  - " << service << std::endl;
    }
    if (!currentAnnouncement.empty()) {
        std::cout << "Current Announcement: " << currentAnnouncement << std::endl;
    }
}

int InformationDesk::getCapacity() const {
    return 50; // Number of people that can queue at desk
}

void InformationDesk::update(Notice* notice) {
    if (notice == nullptr) return;
    
    std::cout << "Information Desk " << deskID << " received: " 
              << notice->getMessage() << std::endl;
    
    switch(notice->getType()) {
        case SCHEDULE_CHANGE:
            provideInfo("Schedule updated: " + notice->getMessage());
            break;
            
        case WEATHER_ALERT:
            broadcastAnnouncement("WEATHER ALERT: " + notice->getMessage() + 
                                 " - Please seek shelter if outdoors");
            break;
            
        case CAPACITY_ALERT:
            broadcastAnnouncement("CAPACITY ALERT: " + notice->getMessage() + 
                                 " - Venue approaching capacity");
            break;
            
        case EVACUATE:
            broadcastAnnouncement("EVACUATION ORDER: " + notice->getMessage() + 
                                 " - Please proceed to nearest exit");
            break;
            
        case OPEN:
            open();
            break;
            
        case CLOSE:
            close();
            break;
            
        default:
            // Store announcement for other notice types
            broadcastAnnouncement("Notice: " + notice->getMessage());
            break;
    }
}

void InformationDesk::provideInfo(const std::string& info) {
    std::cout << "Information Desk " << deskID << " providing: " << info << std::endl;
}

void InformationDesk::addService(const std::string& service) {
    services.push_back(service);
    std::cout << "Service '" << service << "' added to Information Desk " << deskID << std::endl;
}

void InformationDesk::broadcastAnnouncement(const std::string& announcement) {
    currentAnnouncement = announcement;
    std::cout << "📢 ANNOUNCEMENT from Desk " << deskID << ": " << announcement << std::endl;
}
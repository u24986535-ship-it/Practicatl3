#include "SpectatorGate.h"
#include <iostream>

SpectatorGate::SpectatorGate(const std::string& name, int gateNum, int capacity)
    : EventUnit(name), gateNumber(gateNum), maxCapacity(capacity),
      currentOccupancy(0), entryRate(30.0) { // 30 spectators per minute default
    std::cout << "Gate " << gateNumber << " created (capacity: " << capacity << ")" << std::endl;
}

SpectatorGate::~SpectatorGate() {
    std::cout << "Gate " << gateNumber << " destroyed." << std::endl;
}

void SpectatorGate::open() {
    setIsOpen(true);
    std::cout << "Gate " << gateNumber << " opened (entry rate: " 
              << entryRate << " spectators/min)" << std::endl;
}

void SpectatorGate::close() {
    setIsOpen(false);
    std::cout << "Gate " << gateNumber << " closed." << std::endl;
}

void SpectatorGate::reportStatus() const {
    std::cout << "=== Spectator Gate: " << name << " ===" << std::endl;
    std::cout << "Gate Number: " << gateNumber << std::endl;
    std::cout << "Capacity: " << maxCapacity << std::endl;
    std::cout << "Current Occupancy: " << currentOccupancy << std::endl;
    std::cout << "Remaining Capacity: " << getRemainingCapacity() << std::endl;
    std::cout << "Occupancy Rate: " << (getOccupancyRate() * 100) << "%" << std::endl;
    std::cout << "Entry Rate: " << entryRate << " spectators/min" << std::endl;
    std::cout << "Status: " << (isOpen ? "Open" : "Closed") << std::endl;
}

int SpectatorGate::getCapacity() const {
    return maxCapacity;
}

void SpectatorGate::update(Notice* notice) {
    if (notice == nullptr) return;
    
    std::cout << "Gate " << gateNumber << " received: " 
              << notice->getMessage() << std::endl;
    
    switch(notice->getType()) {
        case OPEN:
            open();
            break;
            
        case CLOSE:
            close();
            break;
            
        case CAPACITY_ALERT:
            handleCapacityAlert(notice);
            break;
            
        case WEATHER_ALERT:
            // Close or reduce entry during weather alerts
            if (isOpen) {
                std::cout << "Gate " << gateNumber << " closing due to weather alert" << std::endl;
                close();
            }
            break;
            
        case EVACUATE:
            std::cout << "Gate " << gateNumber << " opening for evacuation" << std::endl;
            open();
            break;
            
        default:
            break;
    }
}

// Remove the parameter name to fix unused parameter warning
void SpectatorGate::handleCapacityAlert(Notice* /*notice*/) {
    double occupancy = getOccupancyRate();
    
    if (occupancy >= 0.95) {
        // Close at 95% capacity
        close();
        std::cout << "Gate " << gateNumber << " closed (95% capacity reached)" << std::endl;
    } else if (occupancy >= 0.80) {
        // Reduce entry rate at 80% capacity
        setEntryRate(entryRate * 0.5);
        std::cout << "Gate " << gateNumber << " entry rate reduced to " 
                  << entryRate << " spectators/min (80% capacity)" << std::endl;
    }
}

bool SpectatorGate::admitSpectator() {
    if (!isOpen) {
        std::cout << "Gate " << gateNumber << " is closed - no admission" << std::endl;
        return false;
    }
    
    if (currentOccupancy >= maxCapacity) {
        std::cout << "Gate " << gateNumber << " at capacity - no more spectators" << std::endl;
        return false;
    }
    
    currentOccupancy++;
    std::cout << "Spectator admitted through Gate " << gateNumber 
              << " (Occupancy: " << currentOccupancy << "/" << maxCapacity << ")" << std::endl;
    return true;
}

int SpectatorGate::getRemainingCapacity() const {
    return maxCapacity - currentOccupancy;
}

void SpectatorGate::setEntryRate(double rate) {
    entryRate = rate;
}

double SpectatorGate::getOccupancyRate() const {
    if (maxCapacity == 0) return 0.0;
    return static_cast<double>(currentOccupancy) / maxCapacity;
}
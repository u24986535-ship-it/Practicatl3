#ifndef MEDICALTEAM_H
#define MEDICALTEAM_H

#include "EventUnit.h"
#include "Observer.h"

/**
 * @brief Represents a medical support team
 * @role Composite Pattern - Leaf
 * @role Observer Pattern - Concrete Observer
 */
class MedicalTeam : public EventUnit, public Observer {
private:
    int staffCount;
    bool available;      // Initialize first
    bool equipmentReady; // Initialize second
    std::string location; // Initialize last
    
public:
    MedicalTeam(const std::string& name, int staff = 5, const std::string& loc = "Main");
    virtual ~MedicalTeam();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    virtual std::string getName() const { return name; }
    
    // Observer interface
    virtual void update(Notice* notice);
    
    // Medical operations
    void activate();
    void deactivate();
    bool isAvailable() const { return available; }
};

#endif
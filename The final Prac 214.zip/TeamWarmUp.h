#ifndef TEAMWARMUP_H
#define TEAMWARMUP_H

#include "EventUnit.h"
#include "Observer.h"

/**
 * @brief Represents a team warm-up session
 * @role Composite Pattern - Leaf
 * @role Observer Pattern - Concrete Subject and Observer
 */
class TeamWarmUp : public EventUnit, public Observer {
private:
    std::string teamName;
    int duration; // in minutes
    bool isActive;
    
public:
    TeamWarmUp(const std::string& name, const std::string& team, int duration = 15);
    virtual ~TeamWarmUp();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    virtual std::string getName() const { return name; }
    
    // Observer interface
    virtual void update(Notice* notice);
    
    // Warm-up operations
    void startWarmUp();
    void endWarmUp();
    bool getIsActive() const { return isActive; }
};

#endif
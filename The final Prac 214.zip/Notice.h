#ifndef NOTICE_H
#define NOTICE_H

#include <string>
#include <ctime>

/**
 * @brief Enumeration of all possible notice types.
 */
enum NoticeType {
    OPEN,               ///< Open notification
    CLOSE,              ///< Close notification
    SCHEDULE_CHANGE,    ///< Schedule change notification
    CAPACITY_ALERT,     ///< Capacity alert notification
    WEATHER_ALERT,      ///< Weather alert notification
    PAUSE,              ///< Pause notification
    RESUME,             ///< Resume notification
    EVACUATE,           ///< Evacuation notification
    SCORE_UPDATE,       ///< Score update notification
    MATCH_START,        ///< Match start notification
    MATCH_END,          ///< Match end notification
    WARMUP_START,       ///< Warm-up start notification
    WARMUP_END,         ///< Warm-up end notification
    CUSTOM              ///< Custom notification type
};

/**
 * @brief Represents a notification message sent from Subjects to Observers.
 * 
 * Notices are owned by the Subject that creates them and are deleted when
 * the Subject is destroyed or when a new notice is set.
 */
class Notice {
private:
    NoticeType type;        ///< Type of the notice
    std::string message;    ///< Message content
    time_t timestamp;       ///< When the notice was created
    std::string source;     ///< Source of the notice
    
public:
    /**
     * @brief Constructs a new Notice.
     * 
     * The timestamp is automatically set to the current time.
     * 
     * @param type The type of notice
     * @param message The message content
     * @param source The source of the notice (defaults to empty string)
     */
    Notice(NoticeType type, const std::string& message, const std::string& source = "")
        : type(type), message(message), source(source) {
        timestamp = time(nullptr);
    }
    
    /**
     * @brief Destroys the Notice.
     */
    ~Notice() {}
    
    /**
     * @brief Gets the notice type.
     * 
     * @return NoticeType The type of notice
     */
    NoticeType getType() const { return type; }
    
    /**
     * @brief Gets the message content.
     * 
     * @return std::string The message
     */
    std::string getMessage() const { return message; }
    
    /**
     * @brief Gets the timestamp when this notice was created.
     * 
     * @return time_t The creation timestamp
     */
    time_t getTimestamp() const { return timestamp; }
    
    /**
     * @brief Gets the source of this notice.
     * 
     * @return std::string The source identifier
     */
    std::string getSource() const { return source; }
    
    /**
     * @brief Converts the notice type to a string representation.
     * 
     * @return std::string String representation of the notice type
     */
    std::string getTypeString() const {
        switch(type) {
            case OPEN: return "OPEN";
            case CLOSE: return "CLOSE";
            case SCHEDULE_CHANGE: return "SCHEDULE_CHANGE";
            case CAPACITY_ALERT: return "CAPACITY_ALERT";
            case WEATHER_ALERT: return "WEATHER_ALERT";
            case PAUSE: return "PAUSE";
            case RESUME: return "RESUME";
            case EVACUATE: return "EVACUATE";
            case SCORE_UPDATE: return "SCORE_UPDATE";
            case MATCH_START: return "MATCH_START";
            case MATCH_END: return "MATCH_END";
            case WARMUP_START: return "WARMUP_START";
            case WARMUP_END: return "WARMUP_END";
            default: return "CUSTOM";
        }
    }
};

#endif
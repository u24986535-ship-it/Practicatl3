#include "Division.h"
#include <iostream>

Division::Division(const std::string& name, const std::string& ageGroup, int maxTeams)
    : EventGroup(name), ageGroup(ageGroup), maxTeams(maxTeams) {
    std::cout << "Division " << name << " created (" << ageGroup << ")" << std::endl;
}

Division::~Division() {
    std::cout << "Division " << name << " destroyed." << std::endl;
}

void Division::open() {
    isOpen = true;
    for (auto child : children) {
        child->open();
    }
    std::cout << "Division " << name << " opened with " 
              << children.size() << " children." << std::endl;
}

void Division::close() {
    isOpen = false;
    for (auto child : children) {
        child->close();
    }
    std::cout << "Division " << name << " closed." << std::endl;
}

void Division::reportStatus() const {
    std::cout << "=== Division: " << name << " ===" << std::endl;
    std::cout << "Age Group: " << ageGroup << std::endl;
    std::cout << "Teams: " << teams.size() << "/" << maxTeams << std::endl;
    std::cout << "Status: " << (isOpen ? "Open" : "Closed") << std::endl;
    std::cout << "Children: " << children.size() << std::endl;
    for (auto child : children) {
        child->reportStatus();
        std::cout << "---" << std::endl;
    }
}

int Division::getCapacity() const {
    int total = 0;
    for (auto child : children) {
        total += child->getCapacity();
    }
    return total;
}

void Division::addTeam(const std::string& team) {
    if (!isFull()) {
        teams.push_back(team);
        std::cout << "Team " << team << " added to Division " << name << std::endl;
    } else {
        std::cout << "Division " << name << " is full (max " << maxTeams << " teams)" << std::endl;
    }
}
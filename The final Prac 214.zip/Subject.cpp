#include "Subject.h"

Subject::~Subject() {
    // Delete current notice if exists
    if (currentNotice != nullptr) {
        delete currentNotice;
        currentNotice = nullptr;
    }
}

void Subject::attach(Observer* observer) {
    if (observer == nullptr) return;
    
    // Check for duplicate registration
    if (!isObserver(observer)) {
        observers.push_back(observer);
        std::cout << "Observer attached to Subject." << std::endl;
    } else {
        std::cout << "Warning: Observer already attached." << std::endl;
    }
}

void Subject::detach(Observer* observer) {
    if (observer == nullptr) return;
    
    auto it = std::find(observers.begin(), observers.end(), observer);
    if (it != observers.end()) {
        observers.erase(it);
        std::cout << "Observer detached from Subject." << std::endl;
    } else {
        std::cout << "Warning: Observer not found for detachment." << std::endl;
    }
}

void Subject::notify() {
    if (currentNotice == nullptr) return;
    
    std::cout << "Notifying " << observers.size() << " observers..." << std::endl;
    for (auto observer : observers) {
        if (observer != nullptr) {
            observer->update(currentNotice);
        }
    }
}

void Subject::setCurrentNotice(Notice* notice) {
    // Delete old notice if exists
    if (currentNotice != nullptr) {
        delete currentNotice;
    }
    currentNotice = notice;
}

bool Subject::isObserver(Observer* observer) const {
    return std::find(observers.begin(), observers.end(), observer) != observers.end();
}
#ifndef EVENTCOMPONENT_H
#define EVENTCOMPONENT_H

#include <string>
#include <iostream>

/**
 * @brief Abstract base class for all event components in the tournament system.
 * 
 * This is the Component participant in the Composite pattern. It defines the common
 * interface for both leaf and composite objects in the tournament hierarchy.
 * 
 * @role Composite Pattern - Component
 */
class EventComponent {
public:
    virtual ~EventComponent() {}
    
    /**
     * @brief Opens the event component for operation.
     * 
     * This operation is propagated to all child components in composite structures.
     */
    virtual void open() = 0;
    
    /**
     * @brief Closes the event component and stops operations.
     * 
     * This operation is propagated to all child components in composite structures.
     */
    virtual void close() = 0;
    
    /**
     * @brief Reports the current status of the event component.
     * 
     * This operation is propagated to all child components in composite structures
     * and provides a complete hierarchical status report.
     */
    virtual void reportStatus() const = 0;
    
    /**
     * @brief Gets the total capacity of this component.
     * 
     * For leaf components, this returns the component's capacity. For composite
     * components, this returns the sum of all child capacities.
     * 
     * @return int Total capacity
     */
    virtual int getCapacity() const = 0;
    
    /**
     * @brief Gets the name of the component.
     * 
     * @return std::string The component's name
     */
    virtual std::string getName() const = 0;
};

#endif
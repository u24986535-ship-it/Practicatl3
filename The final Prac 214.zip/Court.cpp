#include "Court.h"
#include "NetballMatch.h"
#include <iostream>

Court::Court(const std::string& name, const std::string& type, 
             const std::string& surface, int capacity)
    : EventGroup(name), courtType(type), surface(surface), matchCapacity(capacity) {
    std::cout << "Court " << name << " created (" << type << ", " << surface << ")" << std::endl;
}

Court::~Court() {
    std::cout << "Court " << name << " destroyed." << std::endl;
}

void Court::open() {
    isOpen = true;
    for (auto child : children) {
        child->open();
    }
    std::cout << "Court " << name << " opened with " 
              << children.size() << " children." << std::endl;
}

void Court::close() {
    isOpen = false;
    for (auto child : children) {
        child->close();
    }
    std::cout << "Court " << name << " closed." << std::endl;
}

void Court::reportStatus() const {
    std::cout << "=== Court: " << name << " ===" << std::endl;
    std::cout << "Type: " << courtType << std::endl;
    std::cout << "Surface: " << surface << std::endl;
    std::cout << "Status: " << (isOpen ? "Open" : "Closed") << std::endl;
    std::cout << "Children: " << children.size() << std::endl;
    for (auto child : children) {
        child->reportStatus();
        std::cout << "---" << std::endl;
    }
}

int Court::getCapacity() const {
    int total = 0;
    for (auto child : children) {
        total += child->getCapacity();
    }
    return total;
}

void Court::addMatch(NetballMatch* match) {
    if (match != nullptr) {
        add(match);
        std::cout << "Match " << match->getName() << " added to Court " << name << std::endl;
    }
}

void Court::removeMatch(NetballMatch* match) {
    if (match != nullptr) {
        remove(match);
        std::cout << "Match " << match->getName() << " removed from Court " << name << std::endl;
    }
}

bool Court::hasMatch(const std::string& matchName) const {
    for (auto child : children) {
        if (child->getName() == matchName) {
            return true;
        }
    }
    return false;
}
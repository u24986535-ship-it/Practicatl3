#ifndef TOURNAMENTDAY_H
#define TOURNAMENTDAY_H

#include "EventGroup.h"

/**
 * @brief Groups activities occurring on a particular tournament day.
 * 
 * This class manages all divisions, zones, courts, and matches scheduled
 * for a specific day of the tournament.
 * 
 * @role Composite Pattern - Composite
 * @role Observer Pattern - Concrete Subject and Observer
 */
class TournamentDay : public EventGroup {
private:
    std::string date;   ///< Date of the tournament day
    int dayNumber;      ///< Sequential number of the day (1, 2, 3, ...)
    bool isComplete;    ///< Whether all activities for this day are complete
    
public:
    /**
     * @brief Constructs a TournamentDay.
     * 
     * @param name The day name
     * @param date The date in string format
     * @param dayNum The sequential day number
     */
    TournamentDay(const std::string& name, const std::string& date, int dayNum);
    
    /**
     * @brief Destroys the TournamentDay.
     * 
     * All child components are deleted by the EventGroup destructor.
     */
    virtual ~TournamentDay();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    
    /**
     * @brief Marks the day as complete.
     * 
     * This indicates that all scheduled activities for the day have been completed.
     */
    void markComplete();
    
    /**
     * @brief Checks if the day is complete.
     * 
     * @return bool true if complete, false otherwise
     */
    bool getIsComplete() const { return isComplete; }
    
    /**
     * @brief Gets the date of the day.
     * 
     * @return std::string The date string
     */
    std::string getDate() const { return date; }
};

#endif
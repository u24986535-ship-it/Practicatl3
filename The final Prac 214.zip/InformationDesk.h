#ifndef INFORMATIONDESK_H
#define INFORMATIONDESK_H

#include "EventUnit.h"
#include "Observer.h"
#include <vector>

/**
 * @brief Represents an information desk at the tournament venue.
 * 
 * This class provides information services to attendees and broadcasts
 * announcements. It responds to various notices including schedule changes,
 * weather alerts, and evacuation orders.
 * 
 * @role Composite Pattern - Leaf
 * @role Observer Pattern - Concrete Observer
 */
class InformationDesk : public EventUnit, public Observer {
private:
    std::string deskID;             ///< Unique identifier for the desk
    std::string location;           ///< Physical location of the desk
    std::vector<std::string> services; ///< List of services offered
    std::string currentAnnouncement; ///< Current announcement being broadcast
    bool isActive;                  ///< Whether the desk is active
    
public:
    /**
     * @brief Constructs an InformationDesk.
     * 
     * @param name The display name
     * @param id The unique desk identifier
     * @param loc The physical location
     */
    InformationDesk(const std::string& name, const std::string& id, 
                    const std::string& loc);
    
    /**
     * @brief Destroys the InformationDesk.
     */
    virtual ~InformationDesk();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    virtual std::string getName() const { return name; }
    
    // Observer interface
    virtual void update(Notice* notice);
    
    /**
     * @brief Provides information to a request.
     * 
     * @param info The information to provide
     */
    void provideInfo(const std::string& info);
    
    /**
     * @brief Adds a service to the desk's offerings.
     * 
     * @param service The service name to add
     */
    void addService(const std::string& service);
    
    /**
     * @brief Broadcasts an announcement to attendees.
     * 
     * @param announcement The announcement message
     */
    void broadcastAnnouncement(const std::string& announcement);
};

#endif
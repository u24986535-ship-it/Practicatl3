#ifndef EVENTUNIT_H
#define EVENTUNIT_H

#include "EventComponent.h"
#include "Observer.h"
#include "Subject.h"
#include "Notice.h"

/**
 * @brief Abstract base class for leaf components in the tournament hierarchy.
 * 
 * This class represents leaf nodes in the Composite pattern. It extends Subject
 * to allow leaf components to send notifications, but does not manage children.
 * 
 * @role Composite Pattern - Leaf
 */
class EventUnit : public EventComponent, public Subject {
protected:
    std::string name;  ///< Name of the unit
    bool isOpen;       ///< Whether the unit is open
    
public:
    /**
     * @brief Constructs an EventUnit with the given name.
     * 
     * @param name The name of the unit
     */
    EventUnit(const std::string& name) : name(name), isOpen(false) {}
    
    /**
     * @brief Virtual destructor for proper cleanup.
     */
    virtual ~EventUnit() {}
    
    /**
     * @brief Gets the name of the unit.
     * 
     * @return std::string The unit's name
     */
    virtual std::string getName() const { return name; }
    
    /**
     * @brief Sets the open/closed state of the unit.
     * 
     * @param open true to open, false to close
     */
    void setIsOpen(bool open) { isOpen = open; }
};

#endif
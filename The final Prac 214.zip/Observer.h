#ifndef OBSERVER_H
#define OBSERVER_H

#include "Notice.h"

/**
 * @brief Abstract base class for observers in the Observer pattern.
 * 
 * Observers receive notifications from Subjects through the update method.
 * A single observer can observe multiple subjects.
 * 
 * @role Observer Pattern - Observer
 */
class Observer {
public:
    /**
     * @brief Virtual destructor.
     */
    virtual ~Observer() {}
    
    /**
     * @brief Receives a notification from a Subject.
     * 
     * This method is called by the Subject when its state changes. The notice
     * contains type, message, and source information.
     * 
     * @param notice The notice containing update information. The caller
     *               retains ownership of the notice.
     */
    virtual void update(Notice* notice) = 0;
};

#endif
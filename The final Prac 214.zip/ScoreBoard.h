#ifndef SCOREBOARD_H
#define SCOREBOARD_H

#include "EventUnit.h"
#include "Observer.h"

// Forward declaration to avoid circular dependency
class NetballMatch;

/**
 * @brief Represents a scoreboard display that shows match scores.
 * 
 * This class acts as an Observer that displays match information and scores.
 * It can be attached to a NetballMatch to receive score updates and match
 * status changes.
 * 
 * @role Composite Pattern - Leaf
 * @role Observer Pattern - Concrete Observer
 */
class ScoreBoard : public EventUnit, public Observer {
private:
    std::string boardID;        ///< Unique identifier for the scoreboard
    int matchID;                ///< ID of the match being displayed
    int homeScore;              ///< Current home team score on display
    int awayScore;              ///< Current away team score on display
    bool isActive;              ///< Whether the scoreboard is active
    std::string currentMatchName; ///< Name of the currently displayed match
    NetballMatch* observedMatch;  ///< The match being observed (non-owning pointer)
    
public:
    /**
     * @brief Constructs a ScoreBoard.
     * 
     * @param name The display name of the scoreboard
     * @param id The unique identifier for the scoreboard
     */
    ScoreBoard(const std::string& name, const std::string& id);
    
    /**
     * @brief Destroys the ScoreBoard.
     * 
     * The observed match is NOT deleted as it's stored as a non-owning pointer.
     * The caller must ensure the match is properly detached before destruction.
     */
    virtual ~ScoreBoard();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    virtual std::string getName() const { return name; }
    
    // Observer interface
    virtual void update(Notice* notice);
    
    /**
     * @brief Displays the current score on the scoreboard.
     * 
     * If no match is loaded, displays an appropriate message.
     */
    void displayScore();
    
    /**
     * @brief Updates the displayed match scores.
     * 
     * @param home The new home team score
     * @param away The new away team score
     */
    void updateMatch(int home, int away);
    
    /**
     * @brief Sets the match to be displayed.
     * 
     * This method stores a non-owning pointer to the match. The caller must
     * ensure the match remains valid while the scoreboard is attached and
     * should detach before the match is destroyed.
     * 
     * @param match The match to display. Can be nullptr to clear display.
     */
    void setMatch(NetballMatch* match);
    
    /**
     * @brief Gets the board ID.
     * 
     * @return std::string The board ID
     */
    std::string getBoardID() const { return boardID; }
};

#endif
#include "MedicalTeam.h"
#include <iostream>

MedicalTeam::MedicalTeam(const std::string& name, int staff, const std::string& loc)
    : EventUnit(name), staffCount(staff), 
      available(true), 
      equipmentReady(true), 
      location(loc) {
    std::cout << "Medical Team " << name << " created with " << staff 
              << " staff at " << location << std::endl;
}

MedicalTeam::~MedicalTeam() {
    std::cout << "Medical Team " << name << " destroyed." << std::endl;
}

void MedicalTeam::open() {
    setIsOpen(true);
    available = true;
    equipmentReady = true;
    std::cout << "Medical Team " << name << " activated." << std::endl;
}

void MedicalTeam::close() {
    setIsOpen(false);
    available = false;
    equipmentReady = false;
    std::cout << "Medical Team " << name << " deactivated." << std::endl;
}

void MedicalTeam::reportStatus() const {
    std::cout << "=== Medical Team: " << name << " ===" << std::endl;
    std::cout << "Location: " << location << std::endl;
    std::cout << "Staff Count: " << staffCount << std::endl;
    std::cout << "Available: " << (available ? "Yes" : "No") << std::endl;
    std::cout << "Equipment Ready: " << (equipmentReady ? "Yes" : "No") << std::endl;
    std::cout << "Status: " << (isOpen ? "Active" : "Inactive") << std::endl;
}

int MedicalTeam::getCapacity() const {
    return staffCount * 4;
}

void MedicalTeam::update(Notice* notice) {
    if (notice == nullptr) return;
    
    std::cout << "Medical Team " << name << " received: " 
              << notice->getMessage() << std::endl;
    
    switch(notice->getType()) {
        case WEATHER_ALERT:
            std::cout << "Medical Team " << name << " preparing for weather-related incidents" << std::endl;
            activate();
            break;
            
        case CAPACITY_ALERT:
            std::cout << "Medical Team " << name << " preparing for crowd-related incidents" << std::endl;
            activate();
            break;
            
        case EVACUATE:
            std::cout << "Medical Team " << name << " assisting with evacuation" << std::endl;
            activate();
            break;
            
        case PAUSE:
            std::cout << "Medical Team " << name << " remaining on standby during pause" << std::endl;
            // Stay available
            break;
            
        case RESUME:
            std::cout << "Medical Team " << name << " resuming full operations" << std::endl;
            activate();
            break;
            
        case OPEN:
            open();
            break;
            
        case CLOSE:
            if (notice->getMessage().find("event end") != std::string::npos) {
                close();
                std::cout << "Medical Team " << name << " closed for event end." << std::endl;
            } else {
                std::cout << "Medical Team " << name << " remains open despite closure notice" << std::endl;
                // Keep available - don't close for temporary closures
            }
            break;
            
        default:
            // For other notices, ensure available if not already
            if (!available) {
                activate();
            }
            break;
    }
}

void MedicalTeam::activate() {
    available = true;
    equipmentReady = true;
    setIsOpen(true);
    std::cout << "Medical Team " << name << " activated." << std::endl;
}

void MedicalTeam::deactivate() {
    available = false;
    equipmentReady = false;
    setIsOpen(false);
    std::cout << "Medical Team " << name << " deactivated." << std::endl;
}
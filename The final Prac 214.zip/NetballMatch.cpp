#include "NetballMatch.h"
#include <iostream>
#include <ctime>

// Fix: Initialize in the exact order declared in the header
NetballMatch::NetballMatch(const std::string& name, const std::string& home, 
                           const std::string& away, bool outdoor)
    : EventUnit(name), 
      score(0),                    // 1st - matches header order
      opponentScore(0),            // 2nd
      status(SCHEDULED),           // 3rd
      courtName(""),               // 4th
      homeTeam(home),              // 5th
      awayTeam(away),              // 6th
      isOutdoor(outdoor) {         // 7th - last, matches header order
    std::cout << "NetballMatch " << name << " created (" << home << " vs " << away << ")" << std::endl;
}

NetballMatch::~NetballMatch() {
    // Notify observers before destruction
    notify();
    std::cout << "NetballMatch " << name << " destroyed." << std::endl;
}

void NetballMatch::open() {
    setIsOpen(true);
    std::cout << "Match " << name << " opened." << std::endl;
}

void NetballMatch::close() {
    setIsOpen(false);
    std::cout << "Match " << name << " closed." << std::endl;
}

void NetballMatch::reportStatus() const {
    std::cout << "Match: " << name << std::endl;
    std::cout << "  Teams: " << homeTeam << " vs " << awayTeam << std::endl;
    std::cout << "  Score: " << score << " - " << opponentScore << std::endl;
    std::cout << "  Status: " << statusToString(status) << std::endl;
    std::cout << "  Court: " << (isOutdoor ? "Outdoor" : "Indoor") << std::endl;
}

int NetballMatch::getCapacity() const {
    return 500; // Base capacity for a match
}

void NetballMatch::startMatch() {
    if (status == SCHEDULED) {
        status = IN_PROGRESS;
        open();
        Notice* notice = new Notice(MATCH_START, 
                                    "Match started: " + homeTeam + " vs " + awayTeam,
                                    name);
        setCurrentNotice(notice);
        notify();
        std::cout << "Match " << name << " started!" << std::endl;
    }
}

void NetballMatch::updateScore(int newScore, int newOpponentScore) {
    if (status == IN_PROGRESS || status == PAUSED) {
        score = newScore;
        opponentScore = newOpponentScore;
        
        // Create and send score update notice
        Notice* notice = new Notice(SCORE_UPDATE, 
                                    "Score updated: " + std::to_string(score) + 
                                    "-" + std::to_string(opponentScore),
                                    name);
        setCurrentNotice(notice);
        notify();
        
        std::cout << "Score updated: " << homeTeam << " " << score 
                  << " - " << opponentScore << " " << awayTeam << std::endl;
    }
}

void NetballMatch::setStatus(MatchStatus newStatus) {
    status = newStatus;
    notify();
}

void NetballMatch::pauseMatch() {
    if (status == IN_PROGRESS) {
        status = PAUSED;
        Notice* notice = new Notice(PAUSE, 
                                    "Match paused", name);
        setCurrentNotice(notice);
        notify();
        std::cout << "Match " << name << " paused." << std::endl;
    }
}

void NetballMatch::resumeMatch() {
    if (status == PAUSED) {
        status = IN_PROGRESS;
        Notice* notice = new Notice(RESUME, 
                                    "Match resumed", name);
        setCurrentNotice(notice);
        notify();
        std::cout << "Match " << name << " resumed." << std::endl;
    }
}

void NetballMatch::endMatch() {
    status = COMPLETED;
    close();
    Notice* notice = new Notice(MATCH_END, 
                                "Match completed: " + homeTeam + " " + 
                                std::to_string(score) + "-" + 
                                std::to_string(opponentScore) + " " + awayTeam,
                                name);
    setCurrentNotice(notice);
    notify();
    std::cout << "Match " << name << " completed!" << std::endl;
}

std::string NetballMatch::statusToString(MatchStatus s) const {
    switch(s) {
        case SCHEDULED: return "Scheduled";
        case IN_PROGRESS: return "In Progress";
        case PAUSED: return "Paused";
        case COMPLETED: return "Completed";
        case CANCELLED: return "Cancelled";
        default: return "Unknown";
    }
}
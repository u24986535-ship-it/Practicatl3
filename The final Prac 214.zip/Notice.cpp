#include "Notice.h"
#include <iostream>

// Notice is mostly header-only, but we need this for the constructor
// The constructor is already defined in the header
#ifndef SUBJECT_H
#define SUBJECT_H

#include "Observer.h"
#include "Notice.h"
#include <vector>
#include <algorithm>
#include <iostream>
/**
 * @brief Abstract base class for observable objects
 * @role Observer Pattern - Subject
 */
class Subject {
protected:
    std::vector<Observer*> observers;
    Notice* currentNotice;
    
public:
    Subject() : currentNotice(nullptr) {}
    virtual ~Subject();
    
    virtual void attach(Observer* observer);
    virtual void detach(Observer* observer);
    virtual void notify();
    
    // Helper methods
    void setCurrentNotice(Notice* notice);
    Notice* getCurrentNotice() const { return currentNotice; }
    bool isObserver(Observer* observer) const;
    int getObserverCount() const { return observers.size(); }
};

#endif
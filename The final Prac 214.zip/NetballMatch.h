#ifndef NETBALLMATCH_H
#define NETBALLMATCH_H

#include "EventUnit.h"
#include "Notice.h"

/**
 * @brief Represents an individual netball match in the tournament.
 * 
 * This class models a netball match with teams, score tracking, and match
 * status management. It extends EventUnit to integrate with the composite
 * hierarchy and serves as a Subject in the Observer pattern.
 * 
 * @role Composite Pattern - Leaf
 * @role Observer Pattern - Concrete Subject
 */
class NetballMatch : public EventUnit {
public:
    /**
     * @brief Enumeration of possible match statuses.
     */
    enum MatchStatus { SCHEDULED, IN_PROGRESS, PAUSED, COMPLETED, CANCELLED };
    
private:
    int score;              ///< Current score of the home team
    int opponentScore;      ///< Current score of the away team
    MatchStatus status;     ///< Current match status
    std::string courtName;  ///< Name of the court where the match is played
    std::string homeTeam;   ///< Name of the home team
    std::string awayTeam;   ///< Name of the away team
    bool isOutdoor;         ///< Whether the match is played outdoors
    
public:
    /**
     * @brief Constructs a NetballMatch.
     * 
     * @param name The match name/identifier
     * @param home The name of the home team
     * @param away The name of the away team
     * @param outdoor Whether the match is played outdoors (defaults to false)
     */
    NetballMatch(const std::string& name, const std::string& home, 
                 const std::string& away, bool outdoor = false);
    
    /**
     * @brief Destroys the NetballMatch.
     * 
     * Notifies all observers before destruction to ensure they can clean up.
     */
    virtual ~NetballMatch();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    virtual std::string getName() const { return name; }
    
    /**
     * @brief Starts the match if it's currently scheduled.
     * 
     * Changes status to IN_PROGRESS and sends a MATCH_START notification.
     */
    void startMatch();
    
    /**
     * @brief Updates the match score.
     * 
     * Only valid when the match is IN_PROGRESS or PAUSED. Sends a SCORE_UPDATE
     * notification with the new scores.
     * 
     * @param newScore The new score for the home team
     * @param newOpponentScore The new score for the away team
     */
    void updateScore(int newScore, int newOpponentScore);
    
    /**
     * @brief Sets the match status directly.
     * 
     * @param newStatus The new status to set
     */
    void setStatus(MatchStatus newStatus);
    
    /**
     * @brief Pauses the match if it's currently in progress.
     * 
     * Changes status to PAUSED and sends a PAUSE notification.
     */
    void pauseMatch();
    
    /**
     * @brief Resumes the match if it's currently paused.
     * 
     * Changes status to IN_PROGRESS and sends a RESUME notification.
     */
    void resumeMatch();
    
    /**
     * @brief Ends the match.
     * 
     * Changes status to COMPLETED, closes the match, and sends a MATCH_END
     * notification with the final score.
     */
    void endMatch();
    
    /**
     * @brief Gets the home team's score.
     * 
     * @return int The home team score
     */
    int getScore() const { return score; }
    
    /**
     * @brief Gets the away team's score.
     * 
     * @return int The away team score
     */
    int getOpponentScore() const { return opponentScore; }
    
    /**
     * @brief Gets the current match status.
     * 
     * @return MatchStatus The current status
     */
    MatchStatus getStatus() const { return status; }
    
    /**
     * @brief Gets the court name.
     * 
     * @return std::string The court name
     */
    std::string getCourtName() const { return courtName; }
    
    /**
     * @brief Gets whether the match is played outdoors.
     * 
     * @return bool true if outdoor, false if indoor
     */
    bool getIsOutdoor() const { return isOutdoor; }
    
    /**
     * @brief Converts a MatchStatus to a string.
     * 
     * @param s The status to convert
     * @return std::string String representation of the status
     */
    std::string statusToString(MatchStatus s) const;
};

#endif
#include "UmpireBriefing.h"
#include <iostream>

UmpireBriefing::UmpireBriefing(const std::string& name, int matchId, const std::string& time)
    : EventUnit(name), matchID(matchId), briefingTime(time), isConducted(false) {
    std::cout << "Umpire Briefing created for Match " << matchId 
              << " at " << time << std::endl;
}

UmpireBriefing::~UmpireBriefing() {
    std::cout << "Umpire Briefing for Match " << matchID << " destroyed." << std::endl;
}

void UmpireBriefing::open() {
    setIsOpen(true);
    std::cout << "Umpire Briefing for Match " << matchID << " opened." << std::endl;
}

void UmpireBriefing::close() {
    setIsOpen(false);
    std::cout << "Umpire Briefing for Match " << matchID << " closed." << std::endl;
}

void UmpireBriefing::reportStatus() const {
    std::cout << "=== Umpire Briefing: " << name << " ===" << std::endl;
    std::cout << "Match ID: " << matchID << std::endl;
    std::cout << "Time: " << briefingTime << std::endl;
    std::cout << "Conducted: " << (isConducted ? "Yes" : "No") << std::endl;
    std::cout << "Umpires: " << umpires.size() << std::endl;
    for (const auto& umpire : umpires) {
        std::cout << "  - " << umpire << std::endl;
    }
    std::cout << "Status: " << (isOpen ? "Open" : "Closed") << std::endl;
}

int UmpireBriefing::getCapacity() const {
    return 10; // Can accommodate up to 10 umpires
}

void UmpireBriefing::update(Notice* notice) {
    if (notice == nullptr) return;
    
    std::cout << "UmpireBriefing for Match " << matchID << " received: " 
              << notice->getMessage() << std::endl;
    
    switch(notice->getType()) {
        case SCHEDULE_CHANGE:
            std::cout << "📅 Schedule change - rescheduling briefing for Match " 
                      << matchID << std::endl;
            // Update briefing time
            break;
            
        case PAUSE:
            if (isConducted) {
                std::cout << "⏸️  Match paused - umpires on standby" << std::endl;
            }
            break;
            
        case RESUME:
            if (isConducted) {
                std::cout << "▶️  Match resumed - umpires ready" << std::endl;
            }
            break;
            
        case WEATHER_ALERT:
            std::cout << "⚠️ Weather alert - relaying to umpires for Match " 
                      << matchID << std::endl;
            break;
            
        default:
            break;
    }
}

void UmpireBriefing::conductBriefing() {
    if (!isConducted) {
        isConducted = true;
        open();
        
        // Create notice about briefing
        Notice* notice = new Notice(CUSTOM, 
                                    "Umpire briefing conducted for Match " + 
                                    std::to_string(matchID) + " with " + 
                                    std::to_string(umpires.size()) + " umpires",
                                    name);
        setCurrentNotice(notice);
        notify();
        
        std::cout << "📋 Umpire briefing conducted for Match " << matchID << std::endl;
        std::cout << "  " << umpires.size() << " umpires briefed" << std::endl;
    } else {
        std::cout << "Umpire briefing for Match " << matchID << " already conducted" << std::endl;
    }
}

void UmpireBriefing::addUmpire(const std::string& umpire) {
    umpires.push_back(umpire);
    std::cout << "Umpire " << umpire << " added to briefing for Match " << matchID << std::endl;
}
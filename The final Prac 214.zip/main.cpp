#include <iostream>
#include <cassert>
#include "Tournament.h"
#include "TournamentDay.h"
#include "Division.h"
#include "Zone.h"
#include "Court.h"
#include "NetballMatch.h"
#include "TeamWarmUp.h"
#include "UmpireBriefing.h"
#include "ScoreBoard.h"
#include "MedicalTeam.h"
#include "SpectatorGate.h"
#include "InformationDesk.h"
#include "Notice.h"

// Helper function to print test results
void printTestResult(const std::string& testName, bool passed) {
    std::cout << (passed ? "  ✅ PASS" : "  ❌ FAIL") << " - " << testName << std::endl;
}

// Helper function to check if an EventUnit is open (access protected member via public methods)
bool isEventUnitOpen(EventUnit* unit) {
    // We need to use reportStatus or add a getter
    // Since isOpen is protected, we'll track state differently
    // For testing, we'll use the fact that open() and close() change behavior
    return true; // Placeholder - we'll test behavior instead
}

int main() {
    std::cout << "========================================" << std::endl;
    std::cout << "🏐 City Netball Championship EventFlow 🏐" << std::endl;
    std::cout << "========================================" << std::endl;
    std::cout << std::endl;
    
    // ============================================================
    // TEST 1: EventComponent basic operations
    // ============================================================
    std::cout << "=== TEST 1: EventComponent Operations ===" << std::endl;
    
    // Test NetballMatch
    NetballMatch* testMatch = new NetballMatch("Test Match", "Team A", "Team B", true);
    testMatch->open();
    assert(testMatch->getCapacity() == 500);
    assert(testMatch->getName() == "Test Match");
    testMatch->close();
    delete testMatch;
    printTestResult("NetballMatch open/close/capacity/name", true);
    
    // Test TeamWarmUp
    TeamWarmUp* testWarmup = new TeamWarmUp("Test Warmup", "Team A", 20);
    testWarmup->open();
    assert(testWarmup->getCapacity() == 20);
    assert(testWarmup->getName() == "Test Warmup");
    testWarmup->close();
    delete testWarmup;
    printTestResult("TeamWarmUp open/close/capacity/name", true);
    
    // Test UmpireBriefing
    UmpireBriefing* testBriefing = new UmpireBriefing("Test Briefing", 999, "12:00");
    testBriefing->open();
    assert(testBriefing->getCapacity() == 10);
    testBriefing->addUmpire("Umpire 1");
    testBriefing->addUmpire("Umpire 2");
    testBriefing->close();
    delete testBriefing;
    printTestResult("UmpireBriefing open/close/capacity/addUmpire", true);
    
    std::cout << std::endl;
    
    // ============================================================
    // TEST 2: MedicalTeam
    // ============================================================
    std::cout << "=== TEST 2: MedicalTeam ===" << std::endl;
    
    MedicalTeam* testMedical = new MedicalTeam("Test Medical", 10, "Main");
    assert(testMedical->isAvailable() == true);
    assert(testMedical->getCapacity() == 40);
    
    testMedical->deactivate();
    assert(testMedical->isAvailable() == false);
    testMedical->activate();
    assert(testMedical->isAvailable() == true);
    
    // Test update with different notices
    Notice* testNotice = new Notice(WEATHER_ALERT, "Storm coming", "Weather");
    testMedical->update(testNotice);
    assert(testMedical->isAvailable() == true);
    delete testNotice;
    
    testNotice = new Notice(CAPACITY_ALERT, "Capacity high", "Security");
    testMedical->update(testNotice);
    assert(testMedical->isAvailable() == true);
    delete testNotice;
    
    testNotice = new Notice(EVACUATE, "Evacuate now", "Security");
    testMedical->update(testNotice);
    assert(testMedical->isAvailable() == true);
    delete testNotice;
    
    // Test close notice with "event end" message
    testNotice = new Notice(CLOSE, "event end - closing", "Admin");
    testMedical->update(testNotice);
    assert(testMedical->isAvailable() == false);
    delete testNotice;
    
    // Re-activate for next test
    testMedical->activate();
    assert(testMedical->isAvailable() == true);
    
    // Test close notice without "event end" - should remain available
    testNotice = new Notice(CLOSE, "temporary close", "Admin");
    testMedical->update(testNotice);
    // Medical team should still be available
    assert(testMedical->isAvailable() == true);
    delete testNotice;
    
    delete testMedical;
    printTestResult("MedicalTeam activate/deactivate/update", true);
    std::cout << std::endl;
    
    // ============================================================
    // TEST 3: SpectatorGate
    // ============================================================
    std::cout << "=== TEST 3: SpectatorGate ===" << std::endl;
    
    SpectatorGate* testGate = new SpectatorGate("Test Gate", 1, 100);
    assert(testGate->getCapacity() == 100);
    assert(testGate->getRemainingCapacity() == 100);
    assert(testGate->getOccupancyRate() == 0.0);
    
    testGate->open();
    for (int i = 0; i < 50; i++) {
        assert(testGate->admitSpectator() == true);
    }
    assert(testGate->getRemainingCapacity() == 50);
    assert(testGate->getOccupancyRate() == 0.5);
    
    // Test capacity alert - 80%
    testNotice = new Notice(CAPACITY_ALERT, "80% capacity", "Security");
    testGate->update(testNotice);
    delete testNotice;
    
    // Test capacity alert - 95%
    for (int i = 0; i < 45; i++) {
        testGate->admitSpectator();
    }
    testNotice = new Notice(CAPACITY_ALERT, "95% capacity", "Security");
    testGate->update(testNotice);
    delete testNotice;
    // Gate should be closed at 95%
    
    // Test weather alert - should close
    testGate->open();
    testNotice = new Notice(WEATHER_ALERT, "Storm", "Weather");
    testGate->update(testNotice);
    delete testNotice;
    // Gate should be closed
    
    // Test evacuate - should open
    testNotice = new Notice(EVACUATE, "Evacuate", "Security");
    testGate->update(testNotice);
    delete testNotice;
    // Gate should be open
    
    delete testGate;
    printTestResult("SpectatorGate capacity/admit/update", true);
    std::cout << std::endl;
    
    // ============================================================
    // TEST 4: InformationDesk
    // ============================================================
    std::cout << "=== TEST 4: InformationDesk ===" << std::endl;
    
    InformationDesk* testDesk = new InformationDesk("Test Desk", "ID999", "Main");
    assert(testDesk->getCapacity() == 50);
    
    testDesk->addService("Ticket Sales");
    testDesk->addService("Directions");
    
    testNotice = new Notice(SCHEDULE_CHANGE, "Schedule updated", "Admin");
    testDesk->update(testNotice);
    delete testNotice;
    
    testNotice = new Notice(WEATHER_ALERT, "Weather warning", "Weather");
    testDesk->update(testNotice);
    delete testNotice;
    
    testNotice = new Notice(EVACUATE, "Evacuate now", "Security");
    testDesk->update(testNotice);
    delete testNotice;
    
    testDesk->open();
    testDesk->close();
    
    delete testDesk;
    printTestResult("InformationDesk addService/update/open/close", true);
    std::cout << std::endl;
    
    // ============================================================
    // TEST 5: TeamWarmUp
    // ============================================================
    std::cout << "=== TEST 5: TeamWarmUp ===" << std::endl;
    
    TeamWarmUp* testWarmUp2 = new TeamWarmUp("Test Warmup 2", "Team A", 15);
    testWarmUp2->startWarmUp();
    assert(testWarmUp2->getIsActive() == true);
    testWarmUp2->endWarmUp();
    assert(testWarmUp2->getIsActive() == false);
    
    testWarmUp2->startWarmUp();
    testNotice = new Notice(WEATHER_ALERT, "Storm", "Weather");
    testWarmUp2->update(testNotice);
    delete testNotice;
    assert(testWarmUp2->getIsActive() == false);
    
    testWarmUp2->startWarmUp();
    testNotice = new Notice(PAUSE, "Pause", "Admin");
    testWarmUp2->update(testNotice);
    delete testNotice;
    
    testNotice = new Notice(RESUME, "Resume", "Admin");
    testWarmUp2->update(testNotice);
    delete testNotice;
    assert(testWarmUp2->getIsActive() == true);
    
    delete testWarmUp2;
    printTestResult("TeamWarmUp start/end/update", true);
    std::cout << std::endl;
    
    // ============================================================
    // TEST 6: UmpireBriefing
    // ============================================================
    std::cout << "=== TEST 6: UmpireBriefing ===" << std::endl;
    
    UmpireBriefing* testBriefing2 = new UmpireBriefing("Test Briefing 2", 999, "12:00");
    testBriefing2->addUmpire("Umpire 1");
    testBriefing2->addUmpire("Umpire 2");
    
    testBriefing2->conductBriefing();
    assert(testBriefing2->getIsConducted() == true);
    
    testBriefing2->conductBriefing();
    assert(testBriefing2->getIsConducted() == true);
    
    testNotice = new Notice(SCHEDULE_CHANGE, "Schedule updated", "Admin");
    testBriefing2->update(testNotice);
    delete testNotice;
    
    testNotice = new Notice(PAUSE, "Pause", "Admin");
    testBriefing2->update(testNotice);
    delete testNotice;
    
    testNotice = new Notice(RESUME, "Resume", "Admin");
    testBriefing2->update(testNotice);
    delete testNotice;
    
    delete testBriefing2;
    printTestResult("UmpireBriefing addUmpire/conduct/update", true);
    std::cout << std::endl;
    
    // ============================================================
    // TEST 7: ScoreBoard
    // ============================================================
     std::cout << "=== TEST 7: ScoreBoard ===" << std::endl;
    
    ScoreBoard* testSB = new ScoreBoard("Test ScoreBoard", "SB999");
    NetballMatch* testMatch2 = new NetballMatch("Test Match 2", "Team A", "Team B", false);
    
    // Set match and register observer
    testSB->setMatch(testMatch2);
    testMatch2->attach(testSB);  // Register as observer
    assert(testSB->getBoardID() == "SB999");
    
    testNotice = new Notice(MATCH_START, "Match started", "Match");
    testSB->update(testNotice);
    delete testNotice;
    
    testNotice = new Notice(SCORE_UPDATE, "Score: 10-5", "Match");
    testSB->update(testNotice);
    delete testNotice;
    
    testNotice = new Notice(PAUSE, "Paused", "Match");
    testSB->update(testNotice);
    delete testNotice;
    
    testNotice = new Notice(RESUME, "Resumed", "Match");
    testSB->update(testNotice);
    delete testNotice;
    
    testNotice = new Notice(MATCH_END, "Match ended", "Match");
    testSB->update(testNotice);
    delete testNotice;
    
    testSB->updateMatch(15, 10);
    
    // Detach before deleting to avoid issues
    testMatch2->detach(testSB);
    
    // Delete in correct order - match first, then scoreboard
    delete testMatch2;
    delete testSB;
    
    printTestResult("ScoreBoard setMatch/update/updateMatch", true);
    std::cout << std::endl;
    
    // ============================================================
    // TEST 8: EventGroup (Composite)
    // ============================================================
    std::cout << "=== TEST 8: EventGroup (Composite) ===" << std::endl;
    
    Court* testCourt = new Court("Test Court", "Indoor", "Wood");
    NetballMatch* matchA = new NetballMatch("Match A", "A", "B", false);
    NetballMatch* matchB = new NetballMatch("Match B", "C", "D", false);
    
    testCourt->addMatch(matchA);
    testCourt->addMatch(matchB);
    assert(testCourt->getChildCount() == 2);
    
    EventComponent* found = testCourt->findChild("Match A");
    assert(found != nullptr);
    assert(found->getName() == "Match A");
    
    found = testCourt->findChild("Nonexistent");
    assert(found == nullptr);
    
    assert(testCourt->hasMatch("Match A") == true);
    assert(testCourt->hasMatch("Match C") == false);
    
    testCourt->removeMatch(matchA);
    assert(testCourt->getChildCount() == 1);
    assert(testCourt->getCapacity() == 500);
    
    delete testCourt;
    printTestResult("EventGroup add/find/has/remove/capacity", true);
    std::cout << std::endl;
    
    // ============================================================
    // TEST 9: Tournament and TournamentDay
    // ============================================================
    std::cout << "=== TEST 9: Tournament and TournamentDay ===" << std::endl;
    
    Tournament* testTournament = new Tournament("Test Tournament", 2026, "Test Venue");
    TournamentDay* testDay1 = new TournamentDay("Test Day 1", "2026-08-20", 1);
    TournamentDay* testDay2 = new TournamentDay("Test Day 2", "2026-08-21", 2);
    
    testTournament->addDay(testDay1);
    testTournament->addDay(testDay2);
    assert(testTournament->getChildCount() == 2);
    
    TournamentDay* foundDay = testTournament->findDay("Test Day 1");
    assert(foundDay != nullptr);
    assert(foundDay->getDate() == "2026-08-20");
    
    foundDay = testTournament->findDay("Test Day 3");
    assert(foundDay == nullptr);
    
    testDay1->markComplete();
    assert(testDay1->getIsComplete() == true);
    assert(testTournament->getCapacity() == 0);
    
    delete testTournament;
    printTestResult("Tournament addDay/findDay/markComplete/capacity", true);
    std::cout << std::endl;
    
    // ============================================================
    // TEST 10: Division
    // ============================================================
    std::cout << "=== TEST 10: Division ===" << std::endl;
    
    Division* testDivision = new Division("Test Division", "U16", 5);
    testDivision->addTeam("Team A");
    testDivision->addTeam("Team B");
    testDivision->addTeam("Team C");
    testDivision->addTeam("Team D");
    testDivision->addTeam("Team E");
    
    assert(testDivision->isFull() == true);
    
    testDivision->addTeam("Team F");
    assert(testDivision->isFull() == true);
    
    delete testDivision;
    printTestResult("Division addTeam/isFull", true);
    std::cout << std::endl;
    
    // ============================================================
    // TEST 11: Zone
    // ============================================================
    std::cout << "=== TEST 11: Zone ===" << std::endl;
    
    Zone* testZone = new Zone("Test Zone", "North", true);
    Court* testCourt2 = new Court("Test Court 2", "Outdoor", "Hard");
    Court* testCourt3 = new Court("Test Court 3", "Outdoor", "Hard");
    
    testZone->addCourt(testCourt2);
    testZone->addCourt(testCourt3);
    assert(testZone->getCourtCount() == 2);
    assert(testZone->getIsOutdoor() == true);
    assert(testZone->getCapacity() == 0);
    
    delete testZone;
    printTestResult("Zone addCourt/getCourtCount/getIsOutdoor", true);
    std::cout << std::endl;
    
    // ============================================================
    // TEST 12: Subject/Observer
    // ============================================================
    std::cout << "=== TEST 12: Subject/Observer ===" << std::endl;
    
    NetballMatch* subjectMatch = new NetballMatch("Subject Match", "A", "B", false);
    ScoreBoard* observer1 = new ScoreBoard("Observer 1", "OB001");
    ScoreBoard* observer2 = new ScoreBoard("Observer 2", "OB002");
    
    subjectMatch->attach(observer1);
    subjectMatch->attach(observer2);
    assert(subjectMatch->getObserverCount() == 2);
    
    subjectMatch->attach(observer1);
    assert(subjectMatch->getObserverCount() == 2);
    
    subjectMatch->detach(observer1);
    assert(subjectMatch->getObserverCount() == 1);
    
    subjectMatch->detach(observer1);
    assert(subjectMatch->getObserverCount() == 1);
    
    testNotice = new Notice(MATCH_START, "Test notification", "Test");
    subjectMatch->setCurrentNotice(testNotice);
    subjectMatch->notify();
    
    assert(subjectMatch->isObserver(observer2) == true);
    assert(subjectMatch->isObserver(observer1) == false);
    
    delete subjectMatch;
    delete observer1;
    delete observer2;
    printTestResult("Subject attach/detach/notify/isObserver", true);
    std::cout << std::endl;
    
    // ============================================================
    // TEST 13: Notice
    // ============================================================
    std::cout << "=== TEST 13: Notice ===" << std::endl;
    
    Notice* testNotice2 = new Notice(WEATHER_ALERT, "Storm warning", "Weather");
    assert(testNotice2->getType() == WEATHER_ALERT);
    assert(testNotice2->getMessage() == "Storm warning");
    assert(testNotice2->getSource() == "Weather");
    assert(testNotice2->getTypeString() == "WEATHER_ALERT");
    
    delete testNotice2;
    printTestResult("Notice getters/getTypeString", true);
    std::cout << std::endl;
    
    // ============================================================
    // TEST 14: Cascading notification
    // ============================================================
    std::cout << "=== TEST 14: Cascading Notification ===" << std::endl;
    
    TournamentDay* cascadeDay = new TournamentDay("Cascade Day", "2026-08-20", 1);
    Zone* cascadeZone = new Zone("Cascade Zone", "North", true);
    Court* cascadeCourt = new Court("Cascade Court", "Outdoor", "Hard");
    NetballMatch* cascadeMatch = new NetballMatch("Cascade Match", "A", "B", true);
    ScoreBoard* cascadeSB = new ScoreBoard("Cascade SB", "SB999");
    
    cascadeDay->add(cascadeZone);
    cascadeZone->addCourt(cascadeCourt);
    cascadeCourt->addMatch(cascadeMatch);
    cascadeDay->attach(cascadeZone);
    cascadeMatch->attach(cascadeSB);
    
    testNotice = new Notice(WEATHER_ALERT, "Storm coming", "Weather");
    cascadeDay->setCurrentNotice(testNotice);
    cascadeDay->notify();
    
    delete cascadeDay;
    delete cascadeSB;
    printTestResult("Cascading notification through hierarchy", true);
    std::cout << std::endl;
    
    // ============================================================
    // TEST 15: EventGroup propagation
    // ============================================================
    std::cout << "=== TEST 15: EventGroup Propagation ===" << std::endl;
    
    EventGroup* propGroup = new EventGroup("Prop Group");
    EventComponent* propChild1 = new NetballMatch("Prop Child 1", "A", "B", false);
    EventComponent* propChild2 = new NetballMatch("Prop Child 2", "C", "D", false);
    
    propGroup->add(propChild1);
    propGroup->add(propChild2);
    propGroup->open();
    propGroup->close();
    propGroup->reportStatus();
    propGroup->remove(propChild1);
    assert(propGroup->getChildCount() == 1);
    
    delete propGroup;
    printTestResult("EventGroup open/close/reportStatus/remove", true);
    std::cout << std::endl;
    
    // ============================================================
    // TEST 16: NetballMatch conditions
    // ============================================================
    std::cout << "=== TEST 16: NetballMatch Conditions ===" << std::endl;
    
    NetballMatch* conditionMatch = new NetballMatch("Condition Match", "A", "B", false);
    
    conditionMatch->startMatch();
    assert(conditionMatch->getStatus() == NetballMatch::IN_PROGRESS);
    
    conditionMatch->pauseMatch();
    assert(conditionMatch->getStatus() == NetballMatch::PAUSED);
    
    conditionMatch->resumeMatch();
    assert(conditionMatch->getStatus() == NetballMatch::IN_PROGRESS);
    
    conditionMatch->endMatch();
    assert(conditionMatch->getStatus() == NetballMatch::COMPLETED);
    
    conditionMatch->updateScore(10, 5);
    
    NetballMatch* overtimeMatch = new NetballMatch("Overtime Match", "C", "D", false);
    overtimeMatch->startMatch();
    overtimeMatch->updateScore(40, 40);
    
    delete conditionMatch;
    delete overtimeMatch;
    printTestResult("NetballMatch status transitions and overtime", true);
    std::cout << std::endl;
    
    // ============================================================
    // TEST 17: Zone destructor with courts
    // ============================================================
    std::cout << "=== TEST 17: Zone with Courts ===" << std::endl;
    
    Zone* zoneWithCourts = new Zone("Zone With Courts", "East", false);
    Court* courtWithMatches = new Court("Court With Matches", "Indoor", "Wood");
    NetballMatch* matchWithObserver = new NetballMatch("Match With Observer", "A", "B", false);
    ScoreBoard* observerSB = new ScoreBoard("Observer SB", "OB999");
    
    matchWithObserver->attach(observerSB);
    courtWithMatches->addMatch(matchWithObserver);
    zoneWithCourts->addCourt(courtWithMatches);
    
    // Test that destruction works properly
    delete zoneWithCourts;
    delete observerSB; // Delete observer separately since it's not in the tree
    
    printTestResult("Zone with Courts and Observers destruction", true);
    std::cout << std::endl;
    
    // ============================================================
    // TEST 18: NetballMatch destructor with observers
    // ============================================================
    std::cout << "=== TEST 18: NetballMatch Destructor ===" << std::endl;
    
    NetballMatch* matchToDestroy = new NetballMatch("Match To Destroy", "A", "B", false);
    ScoreBoard* sbObserver = new ScoreBoard("SB Observer", "OB888");
    
    matchToDestroy->attach(sbObserver);
    matchToDestroy->startMatch();
    matchToDestroy->updateScore(5, 3);
    
    // Delete match - should notify observers before destruction
    delete matchToDestroy;
    delete sbObserver;
    
    printTestResult("NetballMatch destructor with observers", true);
    std::cout << std::endl;
    
    // ============================================================
    // TEST 19: Court transfer operations
    // ============================================================
    std::cout << "=== TEST 19: Court Transfer Operations ===" << std::endl;
    
    Court* sourceCourt = new Court("Source Court", "Outdoor", "Hard");
    Court* destCourt = new Court("Dest Court", "Indoor", "Wood");
    NetballMatch* transferMatch = new NetballMatch("Transfer Match", "A", "B", false);
    ScoreBoard* transferSB = new ScoreBoard("Transfer SB", "SB777");
    
    sourceCourt->addMatch(transferMatch);
    transferMatch->attach(transferSB);
    
    // Transfer match from source to dest
    sourceCourt->removeMatch(transferMatch);
    destCourt->addMatch(transferMatch);
    
    assert(sourceCourt->getChildCount() == 0);
    assert(destCourt->getChildCount() == 1);
    
    delete sourceCourt;
    delete destCourt;
    delete transferSB;
    
    printTestResult("Court transfer operations", true);
    std::cout << std::endl;
    
    // ============================================================
    // TEST 20: All update cases for MedicalTeam
    // ============================================================
    std::cout << "=== TEST 20: MedicalTeam All Updates ===" << std::endl;
    
    MedicalTeam* fullMedical = new MedicalTeam("Full Medical", 8, "Main");
    
    std::vector<NoticeType> allTypes = {
        OPEN, CLOSE, SCHEDULE_CHANGE, CAPACITY_ALERT, 
        WEATHER_ALERT, PAUSE, RESUME, EVACUATE,
        SCORE_UPDATE, MATCH_START, MATCH_END, CUSTOM
    };
    
    for (auto type : allTypes) {
        Notice* n = new Notice(type, "Test message", "Test");
        fullMedical->update(n);
        delete n;
    }
    
    delete fullMedical;
    printTestResult("MedicalTeam all notice types", true);
    std::cout << std::endl;
    
    // ============================================================
    // FINAL SUMMARY
    // ============================================================
    std::cout << "========================================" << std::endl;
    std::cout << "✅ All tests passed!" << std::endl;
    std::cout << "========================================" << std::endl;
    std::cout << std::endl;
    
  
    
    return 0;
}
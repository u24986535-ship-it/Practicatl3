#ifndef TOURNAMENT_H
#define TOURNAMENT_H

#include "EventGroup.h"

// Forward declaration to avoid circular dependency
class TournamentDay;

/**
 * @brief Root composite representing the entire tournament.
 * 
 * This class serves as the top-level container for all tournament activities.
 * It manages tournament days and coordinates the overall tournament structure.
 * 
 * @role Composite Pattern - Composite
 * @role Observer Pattern - Concrete Subject and Observer
 */
class Tournament : public EventGroup {
private:
    int year;           ///< Year of the tournament
    std::string venue;  ///< Venue where the tournament is held
    
public:
    /**
     * @brief Constructs a Tournament.
     * 
     * @param name The tournament name
     * @param year The year of the tournament
     * @param venue The venue location
     */
    Tournament(const std::string& name, int year, const std::string& venue);
    
    /**
     * @brief Destroys the Tournament.
     * 
     * All child components (TournamentDays) are deleted by the EventGroup destructor.
     */
    virtual ~Tournament();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    
    /**
     * @brief Adds a day to the tournament.
     * 
     * The Tournament takes ownership of the day and will delete it when
     * the Tournament is destroyed.
     * 
     * @param day The TournamentDay to add. Must not be nullptr.
     */
    void addDay(TournamentDay* day);
    
    /**
     * @brief Finds a day by name.
     * 
     * @param dayName The name of the day to find
     * @return TournamentDay* Pointer to the found day, or nullptr if not found
     */
    TournamentDay* findDay(const std::string& dayName);
};

#endif
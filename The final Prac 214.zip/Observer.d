Observer.o: Observer.cpp Observer.h Notice.h

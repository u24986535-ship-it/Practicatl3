#include "Zone.h"
#include "Court.h"
#include <iostream>

// Fix initialization order to match header declaration order
Zone::Zone(const std::string& name, const std::string& area, bool outdoor)
    : EventGroup(name), area(area), isOutdoor(outdoor), courtCount(0) {
    std::cout << "Zone " << name << " created (" << area << ", " 
              << (outdoor ? "Outdoor" : "Indoor") << ")" << std::endl;
}

Zone::~Zone() {
    std::cout << "Zone " << name << " destroyed." << std::endl;
}

void Zone::open() {
    isOpen = true;
    for (auto child : children) {
        child->open();
    }
    std::cout << "Zone " << name << " opened with " 
              << children.size() << " courts." << std::endl;
}

void Zone::close() {
    isOpen = false;
    for (auto child : children) {
        child->close();
    }
    std::cout << "Zone " << name << " closed." << std::endl;
}

void Zone::reportStatus() const {
    std::cout << "=== Zone: " << name << " ===" << std::endl;
    std::cout << "Area: " << area << std::endl;
    std::cout << "Type: " << (isOutdoor ? "Outdoor" : "Indoor") << std::endl;
    std::cout << "Status: " << (isOpen ? "Open" : "Closed") << std::endl;
    std::cout << "Courts: " << children.size() << std::endl;
    for (auto child : children) {
        child->reportStatus();
        std::cout << "---" << std::endl;
    }
}

int Zone::getCapacity() const {
    int total = 0;
    for (auto child : children) {
        total += child->getCapacity();
    }
    return total;
}

void Zone::addCourt(Court* court) {
    if (court != nullptr) {
        add(court);
        courtCount++;
        std::cout << "Court " << court->getName() << " added to Zone " << name << std::endl;
    }
}

int Zone::getCourtCount() const {
    return children.size();  // Only defined here, not in header
}
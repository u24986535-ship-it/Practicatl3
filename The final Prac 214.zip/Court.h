#ifndef COURT_H
#define COURT_H

#include "EventGroup.h"
#include "NetballMatch.h"

/**
 * @brief Groups matches on a particular court.
 * 
 * This class manages matches scheduled on a specific court, tracking
 * court characteristics like type and surface.
 * 
 * @role Composite Pattern - Composite
 * @role Observer Pattern - Concrete Subject and Observer
 */
class Court : public EventGroup {
private:
    std::string courtType;  ///< "Indoor" or "Outdoor"
    std::string surface;    ///< "Hard", "Clay", or "Grass"
    int matchCapacity;      ///< Maximum number of matches this court can host
    
public:
    /**
     * @brief Constructs a Court.
     * 
     * @param name The court name
     * @param type The court type ("Indoor" or "Outdoor")
     * @param surface The surface type ("Hard", "Clay", or "Grass")
     * @param capacity The maximum number of matches (defaults to 3)
     */
    Court(const std::string& name, const std::string& type, 
          const std::string& surface, int capacity = 3);
    
    /**
     * @brief Destroys the Court.
     * 
     * All child components (NetballMatches) are deleted by the EventGroup destructor.
     */
    virtual ~Court();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    
    /**
     * @brief Adds a match to the court.
     * 
     * The Court takes ownership of the match and will delete it when
     * the Court is destroyed.
     * 
     * @param match The NetballMatch to add. Must not be nullptr.
     */
    void addMatch(NetballMatch* match);
    
    /**
     * @brief Removes a match from the court.
     * 
     * The match is removed but NOT deleted. The caller becomes responsible
     * for the match's lifetime.
     * 
     * @param match The NetballMatch to remove
     */
    void removeMatch(NetballMatch* match);
    
    /**
     * @brief Checks if a match with the given name is scheduled on this court.
     * 
     * @param matchName The name of the match to check
     * @return bool true if the match exists on this court
     */
    bool hasMatch(const std::string& matchName) const;
};

#endif
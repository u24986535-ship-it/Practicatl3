#include "TeamWarmUp.h"
#include <iostream>

TeamWarmUp::TeamWarmUp(const std::string& name, const std::string& team, int duration)
    : EventUnit(name), teamName(team), duration(duration), isActive(false) {
    std::cout << "TeamWarmUp for " << teamName << " created (" << duration << " minutes)" << std::endl;
}

TeamWarmUp::~TeamWarmUp() {
    if (isActive) {
        endWarmUp();
    }
    std::cout << "TeamWarmUp for " << teamName << " destroyed." << std::endl;
}

void TeamWarmUp::open() {
    setIsOpen(true);
    std::cout << "Warm-up area for " << teamName << " opened." << std::endl;
}

void TeamWarmUp::close() {
    setIsOpen(false);
    std::cout << "Warm-up area for " << teamName << " closed." << std::endl;
}

void TeamWarmUp::reportStatus() const {
    std::cout << "Team Warm-up: " << name << std::endl;
    std::cout << "  Team: " << teamName << std::endl;
    std::cout << "  Duration: " << duration << " minutes" << std::endl;
    std::cout << "  Status: " << (isActive ? "Active" : "Inactive") << std::endl;
}

int TeamWarmUp::getCapacity() const {
    return 20; // Warm-up area capacity
}

void TeamWarmUp::update(Notice* notice) {
    if (notice == nullptr) return;
    
    std::cout << "TeamWarmUp for " << teamName << " received: " 
              << notice->getMessage() << std::endl;
    
    switch(notice->getType()) {
        case WEATHER_ALERT:
            if (isActive) {
                std::cout << "⚠️ Weather alert - stopping warm-up for " << teamName << std::endl;
                endWarmUp();
            }
            break;
            
        case SCHEDULE_CHANGE:
            std::cout << "📅 Schedule change - adjusting warm-up for " << teamName << std::endl;
            // Could adjust duration or timing
            break;
            
        case PAUSE:
            if (isActive) {
                std::cout << "⏸️  Pausing warm-up for " << teamName << std::endl;
                // Pause the warm-up
            }
            break;
            
        case RESUME:
            if (!isActive && isOpen) {
                std::cout << "▶️  Resuming warm-up for " << teamName << std::endl;
                startWarmUp();
            }
            break;
            
        default:
            break;
    }
}

void TeamWarmUp::startWarmUp() {
    if (!isActive) {
        isActive = true;
        open();
        
        Notice* notice = new Notice(CUSTOM, 
                                    teamName + " warm-up started (" + 
                                    std::to_string(duration) + " minutes)",
                                    name);
        setCurrentNotice(notice);
        notify();
        
        std::cout << "🏃 Warm-up for " << teamName << " started." << std::endl;
    }
}

void TeamWarmUp::endWarmUp() {
    if (isActive) {
        isActive = false;
        close();
        std::cout << "🏃 Warm-up for " << teamName << " ended." << std::endl;
    }
}
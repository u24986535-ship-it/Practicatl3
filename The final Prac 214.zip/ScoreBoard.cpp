#include "ScoreBoard.h"
#include "NetballMatch.h"
#include <iostream>

ScoreBoard::ScoreBoard(const std::string& name, const std::string& id)
    : EventUnit(name), boardID(id), matchID(0), homeScore(0), awayScore(0),
      isActive(false), currentMatchName(""), observedMatch(nullptr) {
    std::cout << "ScoreBoard " << boardID << " created." << std::endl;
}

ScoreBoard::~ScoreBoard() {
    // Only detach if observedMatch is still valid
    if (observedMatch != nullptr) {
        // We don't detach here to avoid double deletion issues
        observedMatch = nullptr;
    }
    std::cout << "ScoreBoard " << boardID << " destroyed." << std::endl;
}

void ScoreBoard::open() {
    setIsOpen(true);
    isActive = true;
    std::cout << "ScoreBoard " << boardID << " activated." << std::endl;
}

void ScoreBoard::close() {
    setIsOpen(false);
    isActive = false;
    std::cout << "ScoreBoard " << boardID << " deactivated." << std::endl;
}

void ScoreBoard::reportStatus() const {
    std::cout << "=== ScoreBoard: " << name << " ===" << std::endl;
    std::cout << "Board ID: " << boardID << std::endl;
    std::cout << "Status: " << (isActive ? "Active" : "Inactive") << std::endl;
    if (!currentMatchName.empty()) {
        std::cout << "Current Match: " << currentMatchName << std::endl;
        std::cout << "Score: " << homeScore << " - " << awayScore << std::endl;
    } else {
        std::cout << "No match currently displayed" << std::endl;
    }
}

int ScoreBoard::getCapacity() const {
    return 1;
}

void ScoreBoard::update(Notice* notice) {
    if (notice == nullptr) return;
    
    std::cout << "ScoreBoard " << boardID << " received: " 
              << notice->getMessage() << std::endl;
    
    switch(notice->getType()) {
        case SCORE_UPDATE:
            displayScore();
            break;
            
        case MATCH_START:
            std::cout << "🏐 Match started on ScoreBoard " << boardID << std::endl;
            isActive = true;
            displayScore();
            break;
            
        case MATCH_END:
            std::cout << "🏐 Match ended on ScoreBoard " << boardID << std::endl;
            std::cout << "FINAL SCORE: " << homeScore << " - " << awayScore << std::endl;
            isActive = false;
            break;
            
        case PAUSE:
            std::cout << "⏸️  PAUSED on ScoreBoard " << boardID << std::endl;
            displayScore();
            break;
            
        case RESUME:
            std::cout << "▶️  RESUMED on ScoreBoard " << boardID << std::endl;
            displayScore();
            break;
            
        default:
            displayScore();
            break;
    }
}

void ScoreBoard::displayScore() {
    if (!currentMatchName.empty()) {
        std::cout << "📊 SCOREBOARD " << boardID << " [" << currentMatchName << "]: " 
                  << homeScore << " - " << awayScore << std::endl;
    } else {
        std::cout << "📊 SCOREBOARD " << boardID << ": No match loaded" << std::endl;
    }
}

void ScoreBoard::updateMatch(int home, int away) {
    homeScore = home;
    awayScore = away;
    displayScore();
}

void ScoreBoard::setMatch(NetballMatch* match) {
    // Don't try to detach from old match - the caller should handle detachment
    // Just update the pointer and display info
    observedMatch = match;
    if (match != nullptr) {
        currentMatchName = match->getName();
        homeScore = match->getScore();
        awayScore = match->getOpponentScore();
        std::cout << "ScoreBoard " << boardID << " set to display match: " 
                  << currentMatchName << std::endl;
        displayScore();
    } else {
        currentMatchName = "";
        homeScore = 0;
        awayScore = 0;
        std::cout << "ScoreBoard " << boardID << " cleared" << std::endl;
    }
}
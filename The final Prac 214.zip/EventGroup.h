#ifndef EVENTGROUP_H
#define EVENTGROUP_H

#include "EventComponent.h"
#include "Subject.h"
#include "Observer.h"
#include <vector>
#include <algorithm>

/**
 * @brief Abstract composite class for event groups in the tournament hierarchy.
 * 
 * This class serves as both a Composite in the Composite pattern and as both
 * a Subject and Observer in the Observer pattern. It manages child components
 * and propagates notifications through the hierarchy.
 * 
 * @role Composite Pattern - Composite
 * @role Observer Pattern - Concrete Subject and Observer
 */
class EventGroup : public EventComponent, public Subject, public Observer {
protected:
    std::string name;                              ///< Name of the group
    std::vector<EventComponent*> children;         ///< Child components (non-owning pointers)
    bool isOpen;                                   ///< Whether the group is open
    
public:
    /**
     * @brief Constructs an EventGroup with the given name.
     * 
     * @param name The name of the group
     */
    EventGroup(const std::string& name);
    
    /**
     * @brief Destroys the EventGroup and all its children.
     * 
     * This destructor deletes all child components using their raw pointers.
     * This is the point where ownership of children is transferred to the
     * parent for destruction.
     */
    virtual ~EventGroup();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    virtual std::string getName() const { return name; }
    
    /**
     * @brief Adds a child component to this group.
     * 
     * The child is stored as a non-owning pointer. Ownership is transferred
     * to this group, meaning the child will be deleted when this group is destroyed.
     * 
     * @param component The child component to add. Must not be nullptr.
     */
    virtual void add(EventComponent* component);
    
    /**
     * @brief Removes a child component from this group.
     * 
     * The child is removed but NOT deleted. The caller becomes responsible
     * for the component's lifetime.
     * 
     * @param component The child component to remove
     */
    virtual void remove(EventComponent* component);
    
    /**
     * @brief Finds a child component by name.
     * 
     * This method performs a recursive search through all child components.
     * 
     * @param name The name of the component to find
     * @return EventComponent* Pointer to the found component, or nullptr if not found
     */
    virtual EventComponent* findChild(const std::string& name);
    
    /**
     * @brief Gets the number of direct child components.
     * 
     * @return int Number of children
     */
    virtual int getChildCount() const { return children.size(); }
    
    // Subject interface (inherited)
    virtual void attach(Observer* observer);
    virtual void detach(Observer* observer);
    virtual void notify();
    
    // Observer interface
    virtual void update(Notice* notice);
    
    /**
     * @brief Propagates a notification to all observers and children.
     * 
     * This method first notifies all registered observers, then propagates
     * the notice to all children that implement the Observer interface.
     * This enables cascade notifications through the hierarchy.
     * 
     * @param notice The notice to propagate
     */
    virtual void propagateNotification(Notice* notice);
    
    /**
     * @brief Gets the list of child components.
     * 
     * @return std::vector<EventComponent*> Vector of child pointers
     */
    std::vector<EventComponent*> getChildren() const { return children; }
};

#endif
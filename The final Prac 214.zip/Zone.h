#ifndef ZONE_H
#define ZONE_H

#include "EventGroup.h"
#include "Court.h"

/**
 * @brief Groups courts within a physical area of the venue.
 * 
 * This class organizes courts by area and type (indoor/outdoor), providing
 * a logical grouping for venue management.
 * 
 * @role Composite Pattern - Composite
 * @role Observer Pattern - Concrete Subject and Observer
 */
class Zone : public EventGroup {
private:
    std::string area;    ///< Name of the area (e.g., "North", "South")
    bool isOutdoor;      ///< Whether the zone is outdoors
    int courtCount;      ///< Number of courts in this zone
    
public:
    /**
     * @brief Constructs a Zone.
     * 
     * @param name The zone name
     * @param area The area name
     * @param outdoor Whether the zone is outdoors (defaults to false)
     */
    Zone(const std::string& name, const std::string& area, bool outdoor = false);
    
    /**
     * @brief Destroys the Zone.
     * 
     * All child components (Courts) are deleted by the EventGroup destructor.
     */
    virtual ~Zone();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    
    /**
     * @brief Adds a court to the zone.
     * 
     * The Zone takes ownership of the court and will delete it when
     * the Zone is destroyed.
     * 
     * @param court The Court to add. Must not be nullptr.
     */
    void addCourt(Court* court);
    
    /**
     * @brief Gets the number of courts in the zone.
     * 
     * @return int Number of courts
     */
    int getCourtCount() const;
    
    /**
     * @brief Gets whether the zone is outdoors.
     * 
     * @return bool true if outdoor, false if indoor
     */
    bool getIsOutdoor() const { return isOutdoor; }
};

#endif
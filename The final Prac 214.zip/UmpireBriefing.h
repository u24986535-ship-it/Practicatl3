#ifndef UMPIREBRIEFING_H
#define UMPIREBRIEFING_H

#include "EventUnit.h"
#include "Observer.h"
#include <vector>
#include <string>

/**
 * @brief Represents an umpire briefing session for a match.
 * 
 * This class manages umpire briefings, tracking which umpires have been
 * briefed and providing a record of the briefing. It responds to schedule
 * changes and other notices that affect umpire assignments.
 * 
 * @role Composite Pattern - Leaf
 * @role Observer Pattern - Concrete Subject and Observer
 */
class UmpireBriefing : public EventUnit, public Observer {
private:
    int matchID;                    ///< ID of the associated match
    std::string briefingTime;       ///< Scheduled time of the briefing
    bool isConducted;               ///< Whether the briefing has been conducted
    std::vector<std::string> umpires; ///< List of umpires who attended
    
public:
    /**
     * @brief Constructs an UmpireBriefing.
     * 
     * @param name The briefing name
     * @param matchId The ID of the associated match
     * @param time The scheduled briefing time
     */
    UmpireBriefing(const std::string& name, int matchId, const std::string& time);
    
    /**
     * @brief Destroys the UmpireBriefing.
     */
    virtual ~UmpireBriefing();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    virtual std::string getName() const { return name; }
    
    // Observer interface
    virtual void update(Notice* notice);
    
    /**
     * @brief Conducts the umpire briefing.
     * 
     * Opens the briefing, marks it as conducted, and sends a notification.
     */
    void conductBriefing();
    
    /**
     * @brief Adds an umpire to the briefing roster.
     * 
     * @param umpire The name of the umpire to add
     */
    void addUmpire(const std::string& umpire);
    
    /**
     * @brief Checks if the briefing has been conducted.
     * 
     * @return bool true if conducted, false otherwise
     */
    bool getIsConducted() const { return isConducted; }
};

#endif
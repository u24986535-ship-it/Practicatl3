#include "EventGroup.h"
#include <iostream>

EventGroup::EventGroup(const std::string& name) : name(name), isOpen(false) {}

EventGroup::~EventGroup() {
    // Delete all children
    for (auto child : children) {
        delete child;
    }
    children.clear();
}

void EventGroup::open() {
    isOpen = true;
    for (auto child : children) {
        child->open();
    }
    std::cout << "Group " << name << " opened with " 
              << children.size() << " children." << std::endl;
}

void EventGroup::close() {
    isOpen = false;
    for (auto child : children) {
        child->close();
    }
    std::cout << "Group " << name << " closed." << std::endl;
}

void EventGroup::reportStatus() const {
    std::cout << "=== Group: " << name << " ===" << std::endl;
    std::cout << "Status: " << (isOpen ? "Open" : "Closed") << std::endl;
    std::cout << "Children: " << children.size() << std::endl;
    for (auto child : children) {
        child->reportStatus();
        std::cout << "---" << std::endl;
    }
}

int EventGroup::getCapacity() const {
    int total = 0;
    for (auto child : children) {
        total += child->getCapacity();
    }
    return total;
}

void EventGroup::add(EventComponent* component) {
    if (component != nullptr) {
        children.push_back(component);
        std::cout << "Added " << component->getName() << " to " << name << std::endl;
    }
}

void EventGroup::remove(EventComponent* component) {
    if (component == nullptr) return;
    
    auto it = std::find(children.begin(), children.end(), component);
    if (it != children.end()) {
        children.erase(it);
        std::cout << "Removed " << component->getName() << " from " << name << std::endl;
        // Note: We do NOT delete the component - ownership is transferred or caller handles it
    }
}

EventComponent* EventGroup::findChild(const std::string& name) {
    for (auto child : children) {
        if (child->getName() == name) {
            return child;
        }
        // If child is EventGroup, search recursively
        EventGroup* group = dynamic_cast<EventGroup*>(child);
        if (group != nullptr) {
            EventComponent* found = group->findChild(name);
            if (found != nullptr) {
                return found;
            }
        }
    }
    return nullptr;
}

void EventGroup::attach(Observer* observer) {
    Subject::attach(observer);
}

void EventGroup::detach(Observer* observer) {
    Subject::detach(observer);
}

void EventGroup::notify() {
    Subject::notify();
}

void EventGroup::update(Notice* notice) {
    std::cout << "Group " << name << " received notification: " 
              << notice->getMessage() << std::endl;
    
    // Propagate to observers and children
    if (notice != nullptr) {
        propagateNotification(notice);
    }
}

void EventGroup::propagateNotification(Notice* notice) {
    // Notify all registered observers
    notify();
    
    // Propagate to children if they are Observers
    for (auto child : children) {
        Observer* observer = dynamic_cast<Observer*>(child);
        if (observer != nullptr) {
            observer->update(notice);
        }
    }
}
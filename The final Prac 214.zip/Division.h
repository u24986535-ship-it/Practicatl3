#ifndef DIVISION_H
#define DIVISION_H

#include "EventGroup.h"

/**
 * @brief Groups matches by age division in the tournament.
 * 
 * This class organizes teams and matches by age group, managing team
 * registrations and capacity limits.
 * 
 * @role Composite Pattern - Composite
 * @role Observer Pattern - Concrete Subject and Observer
 */
class Division : public EventGroup {
private:
    std::string ageGroup;          ///< Age group category (e.g., "U16", "U18")
    int maxTeams;                  ///< Maximum number of teams allowed
    std::vector<std::string> teams; ///< List of team names in this division
    
public:
    /**
     * @brief Constructs a Division.
     * 
     * @param name The division name
     * @param ageGroup The age group category
     * @param maxTeams The maximum number of teams allowed
     */
    Division(const std::string& name, const std::string& ageGroup, int maxTeams);
    
    /**
     * @brief Destroys the Division.
     */
    virtual ~Division();
    
    // EventComponent interface
    virtual void open();
    virtual void close();
    virtual void reportStatus() const;
    virtual int getCapacity() const;
    
    /**
     * @brief Adds a team to the division.
     * 
     * @param team The name of the team to add
     */
    void addTeam(const std::string& team);
    
    /**
     * @brief Checks if the division has reached its maximum team capacity.
     * 
     * @return bool true if full, false otherwise
     */
    bool isFull() const { return teams.size() >= static_cast<size_t>(maxTeams); }
};

#endif
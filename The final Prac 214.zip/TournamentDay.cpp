#include "TournamentDay.h"
#include <iostream>

TournamentDay::TournamentDay(const std::string& name, const std::string& date, int dayNum)
    : EventGroup(name), date(date), dayNumber(dayNum), isComplete(false) {
    std::cout << "Tournament Day " << dayNumber << " created (" << date << ")" << std::endl;
}

TournamentDay::~TournamentDay() {
    std::cout << "Tournament Day " << dayNumber << " destroyed." << std::endl;
}

void TournamentDay::open() {
    isOpen = true;
    for (auto child : children) {
        child->open();
    }
    std::cout << "Day " << dayNumber << " opened with " 
              << children.size() << " divisions/zones." << std::endl;
}

void TournamentDay::close() {
    isOpen = false;
    if (!isComplete) {
        isComplete = true;
    }
    for (auto child : children) {
        child->close();
    }
    std::cout << "Day " << dayNumber << " closed." << std::endl;
}

void TournamentDay::reportStatus() const {
    std::cout << "=== Tournament Day: " << name << " ===" << std::endl;
    std::cout << "Date: " << date << std::endl;
    std::cout << "Day Number: " << dayNumber << std::endl;
    std::cout << "Status: " << (isOpen ? "Open" : "Closed") << std::endl;
    std::cout << "Complete: " << (isComplete ? "Yes" : "No") << std::endl;
    std::cout << "Children: " << children.size() << std::endl;
    for (auto child : children) {
        child->reportStatus();
        std::cout << "---" << std::endl;
    }
}

int TournamentDay::getCapacity() const {
    int total = 0;
    for (auto child : children) {
        total += child->getCapacity();
    }
    return total;
}

void TournamentDay::markComplete() {
    isComplete = true;
    std::cout << "Day " << dayNumber << " marked as complete." << std::endl;
}
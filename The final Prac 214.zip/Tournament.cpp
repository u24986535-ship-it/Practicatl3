#include "Tournament.h"
#include "TournamentDay.h"  // Include the actual class
#include <iostream>

Tournament::Tournament(const std::string& name, int year, const std::string& venue)
    : EventGroup(name), year(year), venue(venue) {
    std::cout << "Tournament '" << name << "' created (" << year << " at " << venue << ")" << std::endl;
}

Tournament::~Tournament() {
    std::cout << "Tournament '" << name << "' destroyed." << std::endl;
}

void Tournament::open() {
    isOpen = true;
    for (auto child : children) {
        child->open();
    }
    std::cout << "Tournament '" << name << "' opened with " 
              << children.size() << " days." << std::endl;
}

void Tournament::close() {
    isOpen = false;
    for (auto child : children) {
        child->close();
    }
    std::cout << "Tournament '" << name << "' closed." << std::endl;
}

void Tournament::reportStatus() const {
    std::cout << "========================================" << std::endl;
    std::cout << "🏆 TOURNAMENT: " << name << std::endl;
    std::cout << "Year: " << year << std::endl;
    std::cout << "Venue: " << venue << std::endl;
    std::cout << "Status: " << (isOpen ? "Open" : "Closed") << std::endl;
    std::cout << "Total Capacity: " << getCapacity() << std::endl;
    std::cout << "Number of Days: " << children.size() << std::endl;
    std::cout << "========================================" << std::endl;
    for (auto child : children) {
        child->reportStatus();
        std::cout << "----------------------------------------" << std::endl;
    }
}

int Tournament::getCapacity() const {
    int total = 0;
    for (auto child : children) {
        total += child->getCapacity();
    }
    return total;
}

void Tournament::addDay(TournamentDay* day) {
    if (day != nullptr) {
        add(day);
        std::cout << "Day " << day->getName() << " added to tournament." << std::endl;
    }
}

TournamentDay* Tournament::findDay(const std::string& dayName) {
    EventComponent* found = findChild(dayName);
    return dynamic_cast<TournamentDay*>(found);
}
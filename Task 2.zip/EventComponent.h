#ifndef EVENT_COMPONENT_H
#define EVENT_COMPONENT_H

#include <string>
#include <iostream> // yea you include in .h

class EventComponent {
protected:
    std::string id;
    std::string name;

public:
    EventComponent(const std::string& id, const std::string& name)
        : id(id), name(name) {}

    // Polymorphic base requires virtual destructor
    virtual ~EventComponent() = default;

    // Uniform entry point for all component operations
    virtual void operation() = 0;

    std::string getId() const { return id; }
    std::string getName() const { return name; }
};

#endif // EVENT_COMPONENT_H
#ifndef SCOREBOARD_DISPLAY_H
#define SCOREBOARD_DISPLAY_H

#include "EventComponent.h"

class ScoreboardDisplay : public EventComponent {
private:
    int homeScore;
    int awayScore;
    int currentQuarter;

public:
    ScoreboardDisplay(const std::string& id, const std::string& name);
    virtual ~ScoreboardDisplay() override = default;

    virtual void operation() override;
    
    void updateScore(int home, int away);
    void setQuarter(int quarter);
};

#endif // SCOREBOARD_DISPLAY_H
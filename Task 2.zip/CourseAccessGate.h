#ifndef COURT_ACCESS_GATE_H
#define COURT_ACCESS_GATE_H

#include "EventComponent.h"

class CourtAccessGate : public EventComponent {
private:
    bool isLocked;
    int spectatorCount;

public:
    CourtAccessGate(const std::string& id, const std::string& name);
    virtual ~CourtAccessGate() override = default;

    virtual void operation() override;

    void lockGate();
    void unlockGate();
    void incrementSpectatorCount();
};

#endif // COURT_ACCESS_GATE_H
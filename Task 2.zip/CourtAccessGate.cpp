#include "CourtAccessGate.h"
#include <iostream>

using namespace std;

CourtAccessGate::CourtAccessGate(const string& id, const string& name)
    : EventComponent(id, name), isLocked(true), spectatorCount(0) {}

void CourtAccessGate::operation() {
    cout << "[ACCESS GATE] " << name << " -> Solenoid: " 
         << (isLocked ? "LOCKED (Restricted)" : "UNLOCKED (Open)")
         << " | Total Spectators Passed: " << spectatorCount << endl;
}

void CourtAccessGate::lockGate() {
    isLocked = true;
}

void CourtAccessGate::unlockGate() {
    isLocked = false;
}

void CourtAccessGate::incrementSpectatorCount() {
    if (!isLocked) {
        spectatorCount++;
    }
}
#ifndef UMPIRE_AUDIO_PACK_H
#define UMPIRE_AUDIO_PACK_H

#include "EventComponent.h"

class UmpireAudioPack : public EventComponent {
private:
    double channelFrequency;
    bool isMuted;

public:
    UmpireAudioPack(const std::string& id, const std::string& name);
    virtual ~UmpireAudioPack() override = default;

    virtual void operation() override;

    void setFrequency(double freq);
    void toggleMute();
};

#endif // UMPIRE_AUDIO_PACK_H
#include "CourtLighting.h"
#include <iostream>

using namespace std;

CourtLighting::CourtLighting(const string& id, const string& name)
    : EventComponent(id, name), intensityLevel(100), isEmergencyMode(false) {}

void CourtLighting::operation() {
    if (isEmergencyMode) {
        cout << "[LIGHTING] " << name << " -> *** EMERGENCY MODE ACTIVE *** "
             << "Strobe flash running at 100% capacity!" << endl;
    } else {
        cout << "[LIGHTING] " << name << " -> Floodlights illuminating at " 
             << intensityLevel << "% power level." << endl;
    }
}

void CourtLighting::setIntensity(int level) {
    if (level < 0) intensityLevel = 0;
    else if (level > 100) intensityLevel = 100;
    else intensityLevel = level;
}

void CourtLighting::triggerEmergencyMode() {
    isEmergencyMode = true;
    intensityLevel = 100;
}
#include "ScoreboardDisplay.h"
#include <iostream>

using namespace std;

ScoreboardDisplay::ScoreboardDisplay(const string& id, const string& name)
    : EventComponent(id, name), homeScore(0), awayScore(0), currentQuarter(1) {}

void ScoreboardDisplay::operation() {
    cout << "[SCOREBOARD] " << name << " -> RENDER FRAME: "
         << "Quarter " << currentQuarter 
         << " | Home: " << homeScore 
         << " - Away: " << awayScore << endl;
}

void ScoreboardDisplay::updateScore(int home, int away) {
    if (home >= 0) homeScore = home;
    if (away >= 0) awayScore = away;
}

void ScoreboardDisplay::setQuarter(int quarter) {
    if (quarter >= 1 && quarter <= 4) {
        currentQuarter = quarter;
    }
}
#ifndef COURT_LIGHTING_H
#define COURT_LIGHTING_H

#include "EventComponent.h"

class CourtLighting : public EventComponent {
private:
    int intensityLevel; // 0 to 100 percentage
    bool isEmergencyMode;

public:
    CourtLighting(const std::string& id, const std::string& name);
    virtual ~CourtLighting() override = default;

    virtual void operation() override;

    void setIntensity(int level);
    void triggerEmergencyMode();
};

#endif // COURT_LIGHTING_H
#include "ShotClockSensor.h"
#include <iostream>

using namespace std;

ShotClockSensor::ShotClockSensor(const string& id, const string& name)
    : EventComponent(id, name), secondsRemaining(35), isTripped(false) {}

void ShotClockSensor::operation() {
    if (secondsRemaining <= 0 || isTripped) {
        cout << "[SHOT CLOCK] " << name << " -> *** BUZZER SOUNDING *** "
             << "Possession timer expired (0s)!" << endl;
    } else {
        cout << "[SHOT CLOCK] " << name << " -> Optical tracking active. "
             << secondsRemaining << " seconds remaining." << endl;
    }
}

void ShotClockSensor::resetClock() {
    secondsRemaining = 35;
    isTripped = false;
}

void ShotClockSensor::tick() {
    if (secondsRemaining > 0) {
        secondsRemaining--;
        if (secondsRemaining == 0) {
            isTripped = true;
        }
    }
}
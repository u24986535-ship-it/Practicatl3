#ifndef SHOT_CLOCK_SENSOR_H
#define SHOT_CLOCK_SENSOR_H

#include "EventComponent.h"

class ShotClockSensor : public EventComponent {
private:
    int secondsRemaining;
    bool isTripped;

public:
    ShotClockSensor(const std::string& id, const std::string& name);
    virtual ~ShotClockSensor() override = default;

    virtual void operation() override;

    void resetClock();
    void tick();
};

#endif // SHOT_CLOCK_SENSOR_H
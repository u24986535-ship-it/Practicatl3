#include "EventGroup.h"
#include <iostream>
#include <algorithm> // FIX 1: Required for std::remove

using namespace std;

// Constructor passing parameters up to base EventComponent initializer list
EventGroup::EventGroup(const string& id, const string& name)
    : EventComponent(id, name) {}

// Polymorphic composite operation execution
void EventGroup::operation() {
    cout << "--- Executing EventGroup: " << name << " ---" << endl;
    
    // Range-based for loop traversing child vector
    for (const auto& child : children) {
        if (child) { // Pointer sanity check to prevent nullptr dereferencing
            child->operation(); // Recursive call down the tree hierarchy
        }
    }
}

// Add child node to composite container
void EventGroup::add(shared_ptr<EventComponent> component) {
    if (component != nullptr) {
        children.push_back(component); // Appending child into smart pointer vector
    }
}

// Remove child node from composite container
void EventGroup::remove(shared_ptr<EventComponent> component) {
    // FIX 2: Corrected typo from 'sremove' to 'std::remove'
    // Erase-Remove Idiom: std::remove shifts matching pointers to end, erase trims vector
    children.erase(
        std::remove(children.begin(), children.end(), component),
        children.end()
    );
}

// FIX 3: Corrected signature and return type to match vector vector getter from EventGroup.h
const vector<shared_ptr<EventComponent>>& EventGroup::getChildren() const {
    return children;
}
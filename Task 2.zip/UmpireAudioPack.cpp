#include "UmpireAudioPack.h"
#include <iostream>

using namespace std;

UmpireAudioPack::UmpireAudioPack(const string& id, const string& name)
    : EventComponent(id, name), channelFrequency(915.5), isMuted(false) {}

void UmpireAudioPack::operation() {
    cout << "[AUDIO PACK] " << name << " -> Signal: " 
         << (isMuted ? "MUTED" : "BROADCASTING")
         << " | Operating Frequency: " << channelFrequency << " MHz" << endl;
}

void UmpireAudioPack::setFrequency(double freq) {
    if (freq > 0.0) {
        channelFrequency = freq;
    }
}

void UmpireAudioPack::toggleMute() {
    isMuted = !isMuted;
}
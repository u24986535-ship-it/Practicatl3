#ifndef EVENT_GROUP_H
#define EVENT_GROUP_H

#include "EventComponent.h"
#include <vector>
#include <memory>
#include <algorithm>

class EventGroup : public EventComponent {
private:
    // Owns child components using smart pointers to manage lifecycle
    std::vector<std::shared_ptr<EventComponent>> children;

public:
    EventGroup(const std::string& id, const std::string& name);
    virtual ~EventGroup() override = default;

    // Composite recursive operation
    virtual void operation() override;

    // Child management interface
    void add(std::shared_ptr<EventComponent> component);
    void remove(std::shared_ptr<EventComponent> component);
    const std::vector<std::shared_ptr<EventComponent>>& getChildren() const;
};

#endif // EVENT_GROUP_H